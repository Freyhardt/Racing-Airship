function trololol = atmosphereset(input)
global ls;
switch input
    case 1
        set(ls.handles.start.ha.edit_t_air,'Enable','off');
        set(ls.handles.start.ha.edit_t_he,'Enable','off');
        set(ls.handles.start.ha.edit_t_delta,'Enable','off');
        set(ls.handles.start.ha.edit_p_air,'Enable','off');
        set(ls.handles.start.ha.edit_p_he,'Enable','off');
        %set(ls.handles.start.ha.edit_p_delta,'Enable','off');
        ls.aerostat.p_air = 100725;
        set(ls.handles.start.ha.edit_p_air,'String',num2str(ls.aerostat.p_air));
        ls.aerostat.p_he = ls.aerostat.p_air + ls.aerostat.p_delta;
        ls.aerostat.t_air = ls.aerostat.kelvin + 14.68;
        ls.aerostat.t_he = ls.aerostat.t_air + ls.aerostat.t_delta;
    case 2
        set(ls.handles.start.ha.edit_t_air,'Enable','off');
        set(ls.handles.start.ha.edit_t_he,'Enable','off');
        set(ls.handles.start.ha.edit_t_delta,'Enable','off');
        set(ls.handles.start.ha.edit_p_air,'Enable','off');
        set(ls.handles.start.ha.edit_p_he,'Enable','off');
        %set(ls.handles.start.ha.edit_p_delta,'Enable','off');
        ls.aerostat.p_air = 96518;
        set(ls.handles.start.ha.edit_p_air,'String',num2str(ls.aerostat.p_air));
        ls.aerostat.p_he = ls.aerostat.p_air + ls.aerostat.p_delta;
        ls.aerostat.t_air = ls.aerostat.kelvin + 35;
        ls.aerostat.t_he = ls.aerostat.t_air + ls.aerostat.t_delta;
    case 3
        set(ls.handles.start.ha.edit_t_air,'Enable','off');
        set(ls.handles.start.ha.edit_t_he,'Enable','off');
        set(ls.handles.start.ha.edit_t_delta,'Enable','off');
        set(ls.handles.start.ha.edit_p_air,'Enable','off');
        set(ls.handles.start.ha.edit_p_he,'Enable','off');
        %set(ls.handles.start.ha.edit_p_delta,'Enable','off');
        ls.aerostat.p_air = 101252;
        set(ls.handles.start.ha.edit_p_air,'String',num2str(ls.aerostat.p_air));
        ls.aerostat.p_he = ls.aerostat.p_air + ls.aerostat.p_delta;
        ls.aerostat.t_air = ls.aerostat.kelvin;
        ls.aerostat.t_he = ls.aerostat.t_air + ls.aerostat.t_delta;
    case 4
        set(ls.handles.start.ha.edit_t_air,'Enable','on');
        set(ls.handles.start.ha.edit_t_he,'Enable','on');
        set(ls.handles.start.ha.edit_t_delta,'Enable','on');
        set(ls.handles.start.ha.edit_p_air,'Enable','on');
        set(ls.handles.start.ha.edit_p_he,'Enable','on');
        set(ls.handles.start.ha.edit_p_delta,'Enable','on');
end
pressureselect(1);
tempunit(ls.settings.tempunit);
aerostats();
