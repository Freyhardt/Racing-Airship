function [shape] = shapeload()
global ls;
dim = ls.settings.dimension;
headline = ls.settings.headlines;
[File, Dir] = uigetfile('*txt','File ausw�hlen');
cd(Dir);
fid = fopen(File, 'r');
if dim == 2
    c = textscan(fid,'%f,%f','headerlines',headline);
else
    c = textscan(fid,'%f,%f,%f','headerlines',headline);  
end
fclose(fid);
shape = cell2mat(c)
ls.geometry.shape = shape;
ls.geometry.set = 2;
ls.geometry.length = max(ls.geometry.shape(:,1));
ls.geometry.thick = max(ls.geometry.shape(:,2))*2;
ls.geometry.l2d = ls.geometry.length / ls.geometry.thick;
