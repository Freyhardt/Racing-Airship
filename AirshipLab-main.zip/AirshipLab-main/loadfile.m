function loadfile()
global ls;
ls.settings.iter = 1;
for i = 1:4
    ls.mass.eng = i;
    ls.mass.control = i;
    eng_pos(0,3);
    name1 = ['edit_eng' num2str(i)];
    name12 = ['eng' num2str(i)];
    set(ls.handles.start.ha.(name1),'String',num2str(ls.mass.(name12).mass));
    name1 = ['edit_eng' num2str(i) '_power'];
    set(ls.handles.start.ha.(name1),'String',num2str(ls.mass.(name12).power));
    name1 = ['edit_eng' num2str(i) '_eff'];
    set(ls.handles.start.ha.(name1),'String',num2str(ls.mass.(name12).eff));
    name1 = ['edit_eng' num2str(i) '_prop'];
    set(ls.handles.start.ha.(name1),'String',num2str(ls.mass.(name12).prop));
    name1 = ['edit_eng' num2str(i) '_relpos'];
    set(ls.handles.start.ha.(name1),'String',num2str(ls.mass.(name12).pos_x));
    eng_pos([i ls.mass.(name12).pos_x] ,8);
    name12 = ['control' num2str(i)];
    name1 = ['edit_control' num2str(i) '_mass'];
    set(ls.handles.start.ha.(name1),'String',num2str(ls.mass.(name12).mass));
    control_pos(0, 3);
    name1 = ['edit_control' num2str(i) '_relpos'];
    set(ls.handles.start.ha.(name1),'String',num2str(ls.mass.(name12).pos_x));
    control_pos([i ls.mass.(name12).pos_x] ,8);
    name12 = ['check_control' num2str(i)];
    set(ls.handles.start.ha.(name12),'Value',ls.mass.controlon(i));
    name12 = ['check_engi' num2str(i)];
    set(ls.handles.start.ha.(name12),'Value',ls.mass.engon(i));
    mass_eng(i,1);
    mass_control(i,1);
end
ls.settings.trimon = 1;
ls.mass.servo = 1;
servo_mass(0, 4);
ls.settings.trimon = 0;
% set(ls.handles.start.ha.edit_servo_relx,'String',num2str(ls.mass.servo01.pos_x));
% servo_mass(1,1);
set(ls.handles.start.ha.menu_servoselect,'Value',1);
for i = 1:5
    name1 = payload_mass(i,4);
    field_mass = ['edit_' name1 '_mass'];
    field_rel = ['edit_' name1 '_relpos'];
    set(ls.handles.start.ha.(field_mass),'String',num2str(ls.mass.(name1).mass));
    set(ls.handles.start.ha.(field_rel),'String',num2str(ls.mass.(name1).pos_x));
    payload_mass(i,2);
end
payload_mass(ls.mass.accu_trim, 6);
set(ls.handles.start.ha.check_mass_varibat,'Value',ls.mass.accu_trim);
set(ls.handles.start.ha.edit_mass_varibat_from,'String',num2str(ls.mass.accu.min_pos));
set(ls.handles.start.ha.edit_mass_varibat_to,'String',num2str(ls.mass.accu.max_pos));
set(ls.handles.start.ha.edit_eng_cable_rel_mass,'String',num2str(ls.mass.eng_cable_per_m));
set(ls.handles.start.ha.edit_servo_cable_rel_mass,'String',num2str(ls.mass.servo_cable_per_m));

set(ls.handles.start.ha.menu_ltw_methode,'Value',ls.ltw.methode);
set(ls.handles.start.ha.edit_ltw_aspect,'String',num2str(ls.ltw.aspect));
set(ls.handles.start.ha.edit_ltw_taper,'String',num2str(ls.ltw.taper));
set(ls.handles.start.ha.edit_ltw_pos,'String',num2str(ls.ltw.start_point));
set(ls.handles.start.ha.check_ltw_opt,'Value',ls.ltw.opt);
ltw_set(6);
set(ls.handles.start.ha.edit_ltw_added_mass,'String',num2str(ls.ltw.added_mass));
set(ls.handles.start.ha.edit_ltw_percent_add_mass,'String',num2str(ls.ltw.perc_addmass));

set(ls.handles.start.ha.edit_length,'String',num2str(ls.geometry.length));
set(ls.handles.start.ha.edit_thickness,'String',num2str(ls.geometry.thick));
set(ls.handles.start.ha.edit_l2d,'String',num2str(ls.geometry.l2d));

set(ls.handles.start.ha.edit_r0,'String',num2str(ls.gertler.r0));
set(ls.handles.start.ha.edit_r1,'String',num2str(ls.gertler.r1));
set(ls.handles.start.ha.edit_cp,'String',num2str(ls.gertler.cp));
set(ls.handles.start.ha.edit_m,'String',num2str(ls.gertler.m));
set(ls.handles.start.ha.slider_r0,'Value',ls.gertler.r0);
set(ls.handles.start.ha.slider_r1,'Value',ls.gertler.r1);
set(ls.handles.start.ha.slider_cp,'Value',ls.gertler.cp);
set(ls.handles.start.ha.slider_m,'Value',ls.gertler.m);
set(ls.handles.start.ha.edit_dots,'String',num2str(ls.geometry.dots));

set(ls.handles.start.ha.edit_power,'String',num2str(ls.perf.power));
set(ls.handles.start.ha.edit_interference,'String',num2str(ls.aerodyn.interference));
set(ls.handles.start.ha.edit_propdia,'String',num2str(ls.perf.prop_dia));

if ls.settings.dynprop == 1
    set(ls.handles.start.ha.edit_prop_min,'Enable','off');
    set(ls.handles.start.ha.edit_prop_max,'Enable','off');
    set(ls.handles.start.ha.edit_propdia,'Enable','on');
    set(ls.handles.start.ha.edit_itersteps,'Enable','off');
    ls.perf.prop_min = ls.perf.prop_dia;
    ls.perf.prop_max = ls.perf.prop_dia;
    set(ls.handles.start.ha.check_dynprop,'Value',1);
else
    set(ls.handles.start.ha.edit_prop_min,'Enable','on');
    set(ls.handles.start.ha.edit_prop_max,'Enable','on');
    set(ls.handles.start.ha.edit_propdia,'Enable','off');
    set(ls.handles.start.ha.edit_itersteps,'Enable','on');
    ls.perf.prop_max = str2double(get(ls.handles.start.ha.edit_prop_max,'String'));
    ls.perf.prop_min = str2double(get(ls.handles.start.ha.edit_prop_min,'String'));
    set(ls.handles.start.ha.check_dynprop,'Value',0);
end
ls.settings.iter = 0;
% volumen();
% sternplain();
% trim;
% ltw_set(4);
% aerodyn(10,1);
% propeller(ls.perf.power);
disp('File Loaded');