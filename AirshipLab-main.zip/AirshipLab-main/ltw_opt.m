function ltw_opt()
global ls;
ls.ltw.start_point = 0.5;
steps = 1000;
for t = 0:steps
    ls.ltw.start_point = t/(steps*2)+0.5;
    sternplain();
    result(t+1) = ls.ltw.mass; 
end
[min_mass y] = min(result);
ls.ltw.start_point = y/(steps*2)+0.5;
set(ls.handles.start.ha.edit_ltw_pos,'String',num2str(ls.ltw.start_point));