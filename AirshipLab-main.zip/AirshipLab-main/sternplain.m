function stern = sternplain()
global ls;
hull_moment = ls.hull.moment;
d_ca_alpha = 2 * pi() * ls.ltw.aspect / (3 + ls.ltw.aspect);
sweep25 = ls.ltw.sweep25;
asp_ratio = ls.ltw.aspect;  %Aspect Ratio | Streckung
tp_ratio = ls.ltw.taper;    %Taper Ratio  | Zuspitzung
x = ls.ltw.start_point;
x = x * ls.geometry.length;
ltw_start = x;
x = hullpos(x);
F = 100;
difference = 1;
t = 0;
v_select = 1;
methode = ls.ltw.methode;
switch methode
    case 1
        while difference > 0.00001
            b = sqrt(asp_ratio * F)/2;
            d = b - x;
            a = F/2 / ( x + (1+tp_ratio) / 2 * (b -x));
            c = a * tp_ratio;
            F_1 = (a + c)/2 * d;
            F_2 = a * x;
            x_25 = tand(sweep25) * d;
            eps = a/4 + x_25 + c * 3/4;
            x_s1 = (a^2 - c^2 + eps*(a + 2*c)) / ( 3*(a+c) );
            x_s2 = 0.5*a;
            x_sp = (x_s1*F_1 + x_s2 * F_2) / (F_1 + F_2);
            y_s = d/3 * (a + 2*c) / (a + c);
            x_np_1 = tand(sweep25) * y_s + a/4;
            x_np_2 = a/4;
            x_np = (x_np_1*F_1 + x_np_2 * F_2) / (F_1 + F_2);
            ls.ltw.arm = ltw_start + x_np - ls.geometry.vsp*ls.geometry.length;
            F_neu = 2 * hull_moment / (ls.aerodyn.rho *d_ca_alpha * ls.ltw.alpha*pi()/180 * ls.ltw.arm) ;%/ 2;
            difference  = abs(1 - F/F_neu);
            F = F_neu;
            t = t+1;
            %pause;
        end
    case 2
        while difference > 0.0001 && t < 10000
            b = sqrt(asp_ratio * F)/2;
            d = b - x;
            a = F/2 / ( x + (1+tp_ratio) / 2 * (b -x));
            c = a * tp_ratio;
            F_1 = (a + c)/2 * d;
            F_2 = a * x;
            x_25 = tand(sweep25) * d;
            eps = a/4 + x_25 + c * 3/4;
            x_s1 = (a^2 - c^2 + eps*(a + 2*c)) / ( 3*(a+c) );
            x_s2 = 0.5*a;
            x_sp = (x_s1*F_1 + x_s2 * F_2) / (F_1 + F_2);
            y_s = d/3 * (a + 2*c) / (a + c);
            x_np_1 = tand(sweep25) * y_s + a/4;
            x_np_2 = a/4;
            x_np = (x_np_1*F_1 + x_np_2 * F_2) / (F_1 + F_2);
            RE = v_select * a / ls.aerodyn.kin_visko;
            surface = F_1 + 1/2*a * (x - hullpos(ltw_start+a));
            hidden = F_2 - 1/2*a * (x - hullpos(ltw_start+a));
            aspect = (d +(x - hullpos(ltw_start+a))/2)^2/surface;
            d_ca_alpha = 2 * pi() * aspect / (3 + aspect);
            f_lco = lco_factor(ca_max(RE)*surface/ls.geometry.volume^(2/3)*0.95);
            ls.ltw.arm = ltw_start + x_np - ls.geometry.vsp*ls.geometry.length;
            surface_neu = hull_moment / (ls.aerodyn.rho *d_ca_alpha * ls.ltw.alpha*pi()/180 * ls.ltw.arm * f_lco*2); %/ 2;
            difference  = abs(1 - surface/surface_neu);
            F = 2*(surface_neu + hidden);
            t = t+1;
            %pause;
        end
end
t = t;
F_1 = (a + c)/2 * d;
F_2 = a * x;
ls.ltw.points_x = [0 a/4 + x_25 - c/4 eps a a a 0 0];
ls.ltw.points_y = [x b b x hullpos(ltw_start+a) 0 0 x];
ls.ltw.area = F;
ls.ltw.surface = F_1 + 1/2*a * (x - hullpos(ltw_start+a));
ls.ltw.span = b;
ls.ltw.mass = ls.ltw.a_weight * ls.ltw.surface * ls.ltw.numbers / 2 + ...
    ls.ltw.a_weight * ls.ltw.surface * ls.ltw.numbers * ls.ltw.ratio_hltw / 2;
ls.ltw.mass2 = ls.ltw.mass;
if ls.ltw.added_mass == 0
    ls.ltw.mass = ls.ltw.mass2 + ls.ltw.addmass;
    ls.ltw.perc_mass = ls.ltw.addmass / ls.ltw.mass2;
else
    ls.ltw.mass = ls.ltw.mass2 * (1 + ls.ltw.perc_mass);
    ls.ltw.addmass = ls.ltw.mass2 * ls.ltw.perc_mass;
end
ls.ltw.sp = ltw_start/ls.geometry.length + x_sp/ls.geometry.length - ls.geometry.vsp;
ls.ltw.np = ltw_start/ls.geometry.length + x_np/ls.geometry.length - ls.geometry.vsp;
for i = 1:length(ls.mass.servos)
    if i <= 9
        name = ['servo0' num2str(i)];
    else
        name = ['servo' num2str(i)];
    end
    if ls.mass.servos(i) == 1 && ls.mass.(name).ltw_on == 1
        ls.mass.(name).pos_x = (ltw_start + a * ls.mass.(name).ltw_pos)/ls.geometry.length;
    end
end



