function outcome = pressureselect(choose)
global ls;
p_air = str2num(get(ls.handles.start.ha.edit_p_air,'String'));
p_he = str2num(get(ls.handles.start.ha.edit_p_he,'String'));
p_delta = str2num(get(ls.handles.start.ha.edit_p_delta,'String'));
switch choose
    case 1
        p_he = p_air + p_delta;
        set(ls.handles.start.ha.edit_p_he,'String',num2str(p_he));
        ls.aerostat.p_he = p_he;
        ls.aerostat.p_air = p_air;
        ls.aerostat.p_delta = p_delta;
    case 3
        p_he = p_air + p_delta;
        set(ls.handles.start.ha.edit_p_he,'String',num2str(p_he));
        ls.aerostat.p_he = p_he;
        ls.aerostat.p_air = p_air;
        ls.aerostat.p_delta = p_delta;
    case 2
        p_delta = p_he - p_air;
        set(ls.handles.start.ha.edit_p_delta,'String',num2str(p_delta));
        ls.aerostat.p_delta = p_delta;
        ls.aerostat.p_air = p_air;
        ls.aerostat.p_he = p_he;
end