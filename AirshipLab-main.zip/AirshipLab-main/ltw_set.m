function ltw_set(t)
global ls;
switch t
    case 1
        ls.ltw.start_point = str2double(get(ls.handles.start.ha.edit_ltw_pos,'String'));
    case 2
        ls.ltw.aspect = str2double(get(ls.handles.start.ha.edit_ltw_aspect,'String'));
    case 3
        ls.ltw.taper = str2double(get(ls.handles.start.ha.edit_ltw_taper,'String'));
    case 4
        set(ls.handles.start.ha.edit_hull_moment,'String',num2str(ls.hull.moment));
        set(ls.handles.start.ha.edit_hull_k_factor,'String',num2str(ls.hull.k));
    case 5
        ls.ltw.sweep25 = str2double(get(ls.handles.start.ha.edit_ltw_phi25,'String'));
    case 6
        ls.ltw.sweep100 = str2double(get(ls.handles.start.ha.edit_ltw_phi100,'String'));
    case 7
        ls.ltw.ratio_hltw = str2double(get(ls.handles.start.ha.edit_ltw_ratio_hltw,'String'));
    case 8
        ls.ltw.opt = get(ls.handles.start.ha.check_ltw_opt,'Value');
        if ls.ltw.opt == 1
            set(ls.handles.start.ha.edit_ltw_pos,'Enable','off');
        else
            set(ls.handles.start.ha.edit_ltw_pos,'Enable','on');
        end
    case 9
        ls.ltw.added_mass = 0;
        ls.ltw.addmass = str2double(get(ls.handles.start.ha.edit_ltw_added_mass,'String'));
        ls.ltw.perc_mass = ls.ltw.addmass / ls.ltw.mass2;
        set(ls.handles.start.ha.edit_ltw_percent_add_mass,'String',num2str(ls.ltw.perc_mass*100));
    case 10
        ls.ltw.added_mass = 1;
        ls.ltw.perc_mass = str2double(get(ls.handles.start.ha.edit_ltw_percent_add_mass,'String'))/100;
        ls.ltw.addmass = ls.ltw.mass2 * ls.ltw.perc_mass;
        set(ls.handles.start.ha.edit_ltw_added_mass,'String',num2str(ls.ltw.addmass));
    case 11
        switch ls.ltw.methode
            case 1
              set(ls.handles.start.ha.check_ltw_opt,'Enable','on');
              ltw_set(8);
            case 2
              set(ls.handles.start.ha.check_ltw_opt,'Enable','off');
              set(ls.handles.start.ha.edit_ltw_pos,'Enable','on');
              ls.ltw.opt = 0;
        end
            
end
if t ~= 1 && ls.ltw.opt == 1
    ltw_opt();
end
if ls.settings.iter == 0
sternplain();
set(ls.handles.start.ha.edit_ltw_tip,'String', num2str(ls.ltw.points_x(3)-ls.ltw.points_x(2)));
set(ls.handles.start.ha.edit_ltw_mid,'String', num2str(ls.ltw.points_x(4)-ls.ltw.points_x(1)));
set(ls.handles.start.ha.edit_ltw_root,'String', num2str(((ls.ltw.points_x(2)-ls.ltw.points_x(1))/(ls.ltw.points_y(3)-ls.ltw.points_y(4))*(ls.ltw.points_y(4)-ls.ltw.points_y(5))+(ls.ltw.points_x(4)-ls.ltw.points_x(1)))));
set(ls.handles.start.ha.edit_ltw_frontb,'String', num2str(ls.ltw.points_y(2)-ls.ltw.points_y(1)));
set(ls.handles.start.ha.edit_ltw_backb,'String', num2str(ls.ltw.points_y(3)-ls.ltw.points_y(5)));
set(ls.handles.start.ha.edit_ltw_area,'String', num2str(ls.ltw.area));
set(ls.handles.start.ha.edit_ltw_surface,'String', num2str(ls.ltw.surface));
set(ls.handles.start.ha.edit_ltw_span,'String', num2str(ls.ltw.span));
set(ls.handles.start.ha.edit_ltw_mass,'String', num2str(ls.ltw.mass));
set(ls.handles.start.ha.edit_ltw_span,'String', num2str(ls.ltw.span));
set(ls.handles.start.ha.edit_ltw_percent_add_mass,'String',num2str(ls.ltw.perc_mass*100));
set(ls.handles.start.ha.edit_ltw_added_mass,'String',num2str(ls.ltw.addmass));

drawing();
end