function werte = gertler_daten(vari)
global ls;
if vari < 10 && ls.geometry.set == 2
    lol = 3
end
ls.geometry.set = 1;
switch vari
    case 1
        werte.l2d = ls.geometry.l2d;
        werte.r_0 = ls.gertler.r0;
        werte.r_1 = ls.gertler.r1;
        werte.cp = ls.gertler.cp;
        werte.m = ls.gertler.m;
    case 2 %4154
        werte.r_0 = 0.5;
        werte.r_1 = 0.1;
        werte.cp = 0.65;
        werte.l2d = 4;
        werte.m = 0.4;
    case 3 %4155
        werte.r_0 = 0.5;
        werte.r_1 = 0.1;
        werte.cp = 0.65;
        werte.l2d = 7;
        werte.m = 0.5;
    case 4 %4165
        werte.r_0 = 0.5;
        werte.r_1 = 0.1;
        werte.cp = 0.60;
        werte.l2d = 7;
        werte.m = 0.4;
    case 5 %4166
        werte.r_0 = 0.5;
        werte.r_1 = 0.1;
        werte.cp = 0.70;
        werte.l2d = 7;
        werte.m = 0.4;
    case 6 %4168
        werte.r_0 = 0.3;
        werte.r_1 = 0.1;
        werte.cp = 0.65;
        werte.l2d = 7;
        werte.m = 0.4;
    case 7 %4169
        werte.r_0 = 0.7;
        werte.r_1 = 0.1;
        werte.cp = 0.65;
        werte.l2d = 7;
        werte.m = 0.4;
    case 8 %4621 (original L:4.572m)
        werte.r_0 = 0.6;
        werte.r_1 = 0.0;
        werte.cp = 0.6;
        werte.l2d = 7.34;
        werte.m = 0.4;
    case 9 %own Shape
        ls.geometry.set = 2;
        set(ls.handles.start.ha.edit_r0,'Enable','off');
        set(ls.handles.start.ha.edit_r1,'Enable','off');
        set(ls.handles.start.ha.edit_cp,'Enable','off');
        set(ls.handles.start.ha.edit_m,'Enable','off');
        set(ls.handles.start.ha.slider_r0,'Enable','off');
        set(ls.handles.start.ha.slider_r1,'Enable','off');
        set(ls.handles.start.ha.slider_cp,'Enable','off');
        set(ls.handles.start.ha.slider_m,'Enable','off');
end


if vari < 9
    ls.geometry.set = 1;
    ls.geometry.thick = ls.geometry.length/werte.l2d;
    set(ls.handles.start.ha.edit_r0,'Enable','on');
    set(ls.handles.start.ha.edit_r1,'Enable','on');
    set(ls.handles.start.ha.edit_cp,'Enable','on');
    set(ls.handles.start.ha.edit_m,'Enable','on');
    set(ls.handles.start.ha.slider_r0,'Enable','on');
    set(ls.handles.start.ha.slider_r1,'Enable','on');
    set(ls.handles.start.ha.slider_cp,'Enable','on');
    set(ls.handles.start.ha.slider_m,'Enable','on');
    ls.gertler.r0 = werte.r_0;
    ls.gertler.r1 = werte.r_1;
    ls.gertler.cp = werte.cp;
    ls.geometry.l2d = werte.l2d;
    ls.gertler.m = werte.m;
    set(ls.handles.start.ha.edit_cp,'String',werte.cp);
    set(ls.handles.start.ha.edit_r0,'String',werte.r_0);
    set(ls.handles.start.ha.edit_r1,'String',werte.r_1);
    set(ls.handles.start.ha.edit_m,'String',werte.m);
    set(ls.handles.start.ha.edit_l2d,'String',werte.l2d);
set(ls.handles.start.ha.edit_thickness,'String',ls.geometry.thick);
end


volumen();