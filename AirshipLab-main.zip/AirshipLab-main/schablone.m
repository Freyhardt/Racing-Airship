function schablone()
global ls;
shape = ls.geometry.shape;
shape = shape;% * ls.geometry.length;
cut_x(1) = 0;
cut_y(1) = 0;
for i = 1:length(shape(:,1))-1
    cut_x(i+1) = cut_x(i) + ((shape(i+1,1)-shape(i,1))^2 + (shape(i+1,2)-shape(i,2))^2)^(1/2);
    cut_y(i+1) = 2*shape(i+1,2)*pi()/ls.geometry.cuts/2;
end
ls.geometry.cut_x = cut_x';
ls.geometry.cut_y = cut_y';