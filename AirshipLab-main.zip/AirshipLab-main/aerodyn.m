function result = aerodyn(speed, methode)
global ls;
%methode select
% 1 = Prandtl Plattentherie
if speed == 0
    ls.aerodyn.c_w = 0;
    ls.aerodyn.drag = 0;
    ls.ltw.drag = 0;
else
switch methode
    case 1
        ls.aerodyn.kin_visko = 17.1 * 10^(-6) / ls.aerodyn.rho;
       Re = speed * ls.geometry.length / ls.aerodyn.kin_visko;
       c_w_fric = 0.455 / ((log10(Re))^2.58);
       drag_hull = ls.aerodyn.rho/2 * speed^2 * c_w_fric * ls.geometry.surface(1);
       ls.aerodyn.drag_hull = drag_hull * (1 + 1.5 * (1/ls.geometry.l2d)^(3/2) + ...
           7 * (1/ls.geometry.l2d)^3);
       ls.ltw.drag = ls.aerodyn.rho/2 * speed^2 * ls.ltw.c_w * ls.ltw.surface;
       ls.aerodyn.drag = ls.aerodyn.interference * (ls.aerodyn.drag_hull + ls.ltw.drag);
       ls.aerodyn.c_w = ls.aerodyn.drag / (ls.aerodyn.rho/2 * speed^2 * ...
           ls.geometry.volume);
    case 2
        
end
end
result = ls.aerodyn.drag;