function mass = eng_mass(power)
power = power / 0.35;
mass = -3*10^(-6)*power^2 + 0.2323*power;