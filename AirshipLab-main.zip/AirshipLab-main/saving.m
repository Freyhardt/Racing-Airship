function saving()
global ls;
[file,path] = uigetfile('.mat','Projekt exportieren...');
loadfrom = strcat(path, file);
neu = load(loadfrom);
ls = neu.ls