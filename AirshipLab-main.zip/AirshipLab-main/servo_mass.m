function check = servo_mass(axis,part)
global ls;
switch axis(1)
    case 1
        rel_name = 'edit_servo_relx';
        abs_name = 'edit_servo_absx';
        slider_name = 'slider_servo_x';
        field = 'pos_x';
        min = -0.2;
        max = 1.2;
    case 2
        rel_name = 'edit_servo_rely';
        abs_name = 'edit_servo_absy';
        slider_name = 'slider_servo_y';
        field = 'pos_y';
        min = -2;
        max = 2;
    case 3
        rel_name = 'edit_servo_relz';
        abs_name = 'edit_servo_absz';
        slider_name = 'slider_servo_z';
        field = 'pos_z';
        min = -2;
        max = 2;
end
%name = get(ls.handles.start.ha.menu_servoselect,'String');
%ls.mass.servo = str2double(name(ls.mass.servo,7:8));
if ls.mass.servo > 9
    servo = ['servo' num2str(ls.mass.servo)];
else
    servo = ['servo0' num2str(ls.mass.servo)];
end
switch part
    case 1
        edit = str2double(get(ls.handles.start.ha.(rel_name),'String'));
        set(ls.handles.start.ha.(slider_name),'Value',edit);
        ls.mass.(servo).(field) = edit;
        set(ls.handles.start.ha.(abs_name),'String',ls.mass.(servo).(field)*ls.geometry.length);
    case 2
        slider = get(ls.handles.start.ha.(slider_name),'Value');
        set(ls.handles.start.ha.(rel_name),'String',num2str(slider));
        ls.mass.(servo).(field) = slider;
        set(ls.handles.start.ha.(abs_name),'String',ls.mass.(servo).(field)*ls.geometry.length);
    case 3
        abs = str2double(get(ls.handles.start.ha.(abs_name),'String'));
        abs = abs / ls.geometry.length;
        set(ls.handles.start.ha.(slider_name),'Value',abs);
        ls.mass.(servo).(field) = abs;
        set(ls.handles.start.ha.(rel_name),'String',ls.mass.(servo).(field));
    case 4
        set(ls.handles.start.ha.edit_servo_relx,'String',num2str(ls.mass.(servo).pos_x));
        set(ls.handles.start.ha.edit_servo_rely,'String',num2str(ls.mass.(servo).pos_y));
        set(ls.handles.start.ha.edit_servo_relz,'String',num2str(ls.mass.(servo).pos_z));
        set(ls.handles.start.ha.edit_servo_absx,'String',num2str(ls.mass.(servo).pos_x*ls.geometry.length));
        set(ls.handles.start.ha.edit_servo_absy,'String',num2str(ls.mass.(servo).pos_y*ls.geometry.length));
        set(ls.handles.start.ha.edit_servo_absz,'String',num2str(ls.mass.(servo).pos_z*ls.geometry.length));
        set(ls.handles.start.ha.slider_servo_x,'Value',ls.mass.(servo).pos_x);
        set(ls.handles.start.ha.slider_servo_y,'Value',ls.mass.(servo).pos_y);
        set(ls.handles.start.ha.slider_servo_z,'Value',ls.mass.(servo).pos_z);
        set(ls.handles.start.ha.slider_servo_z,'Value',ls.mass.(servo).pos_z);
        set(ls.handles.start.ha.edit_servo_rel_ltw,'String',ls.mass.(servo).ltw_pos);
        set(ls.handles.start.ha.edit_servo_mass,'String',num2str(ls.mass.(servo).mass));
        if ls.mass.(servo).ltw_on == 1
            status = 'on';
        else
            status = 'off';
        end
        set(ls.handles.start.ha.edit_servo_rel_ltw,'Enable',status);
        set(ls.handles.start.ha.check_servoconnect,'Value',ls.mass.(servo).ltw_on);
    case 5
        vector = length(ls.mass.servos);
        ls.mass.servos(vector + 1) = 1;
        string = '';
        t = 1;
        for i = 1:vector+1
            if ls.mass.servos(i) == 1
                if i < 10
                    string(t,:) = ['Servo_0' num2str(i)];
                else
                    string(t,:) = ['Servo_' num2str(i)];
                end
                t = t+1;
            end
        end
        set(ls.handles.start.ha.menu_servoselect,'String',string);
        if vector < 9
            name = ['servo0' num2str(vector+1)];
        else
            name = ['servo' num2str(vector+1)];
        end
        ls.mass.(name).pos_x = 0;
        ls.mass.(name).pos_y = 0;
        ls.mass.(name).pos_z = 0;
        ls.mass.(name).mass = 0;
        ls.mass.(name).ltw_on = 0;
        ls.mass.(name).ltw_pos = 0.5;
    case 6
        if ls.mass.servo ~= 1
            ls.mass.servos(ls.mass.servo) = 0;
            vector = length(ls.mass.servos);
            string = '';
            t = 1;
            for i = 1:vector
                if ls.mass.servos(i) == 1
                    if i < 10
                        string(t,:) = ['Servo_0' num2str(i)];
                    else
                        string(t,:) = ['Servo_' num2str(i)];
                    end
                    t = t+1;
                end
            end
            set(ls.handles.start.ha.menu_servoselect,'String',string);
            servo_mass(0,4);
            ls.mass.servo = str2double(string(1,7:8));
            set(ls.handles.start.ha.menu_servoselect,'Value',1);
            totalmass(1);
        end
    case 7
        ls.mass.(servo).mass = str2double(get(ls.handles.start.ha.edit_servo_mass,'String'));
        totalmass(1);
    case 8
        ls.mass.(servo).ltw_pos = str2double(get(ls.handles.start.ha.edit_servo_rel_ltw,'String'));
    case 9
        ls.mass.(servo).ltw_on = get(ls.handles.start.ha.check_servoconnect,'Value');
        if ls.mass.(servo).ltw_on == 1
            set(ls.handles.start.ha.edit_servo_rel_ltw,'Enable','on');
        else
            set(ls.handles.start.ha.edit_servo_rel_ltw,'Enable','off');
        end
        sternplain();
        servo_mass(1, 4);
        
end
if ls.settings.trimon == 0
    trim;
end
