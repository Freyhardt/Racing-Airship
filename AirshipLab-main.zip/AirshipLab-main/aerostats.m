function result = aerostats()
global ls;
ls.aerostat.rho_air = ls.aerostat.p_air/ls.aerostat.r_air/ls.aerostat.t_air;
ls.aerostat.rho_he = ls.aerostat.p_he/ls.aerostat.r_he/ls.aerostat.t_he;
ls.aerostat.lift_kg = (ls.aerostat.rho_air-ls.aerostat.rho_he)*ls.geometry.volume;
ls.aerostat.lift_n = (ls.aerostat.rho_air-ls.aerostat.rho_he)*ls.geometry.volume*9.81;
ls.aerostat.lift_spec = ls.aerostat.rho_air-ls.aerostat.rho_he;
if ls.settings.iter == 0
set(ls.handles.start.ha.edit_lift_kg,'String',num2str(ls.aerostat.lift_kg));
set(ls.handles.start.ha.edit_lift_n,'String',num2str(ls.aerostat.lift_n));
set(ls.handles.start.ha.edit_lift_spec,'String',num2str(ls.aerostat.lift_spec));
set(ls.handles.start.ha.edit_density_air,'String',num2str(ls.aerostat.rho_air));
set(ls.handles.start.ha.edit_density_he,'String',num2str(ls.aerostat.rho_he));
end