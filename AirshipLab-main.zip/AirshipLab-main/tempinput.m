function outcome = tempinput(changed)
global ls;
t_air = str2num(get(ls.handles.start.ha.edit_t_air,'String'));
t_he = str2num(get(ls.handles.start.ha.edit_t_he,'String'));
t_delta = str2num(get(ls.handles.start.ha.edit_t_delta,'String'));
switch changed
    case 1
        t_he = t_air + t_delta;
        set(ls.handles.start.ha.edit_t_he,'String',num2str(t_he));
    case 3
        t_he = t_air + t_delta;
        set(ls.handles.start.ha.edit_t_he,'String',num2str(t_he));
    case 2
        t_delta = t_he - t_air;
        set(ls.handles.start.ha.edit_t_delta,'String',num2str(t_delta));
end
switch ls.settings.tempunit
    case 1
        ls.aerostat.t_air = t_air + ls.aerostat.kelvin;
        ls.aerostat.t_he = t_he + ls.aerostat.kelvin;
        ls.aerostat.t_delta = t_delta;
    case 2
        ls.aerostat.t_air = t_air*5/9 + 459.67;
        ls.aerostat.t_he = t_he*5/9 + 459.67;
        ls.aerostat.t_delta = t_delta*5/9;
    case 3
        ls.aerostat.t_air = t_air;
        ls.aerostat.t_he = t_he;
        ls.aerostat.t_delta = t_delta;
end