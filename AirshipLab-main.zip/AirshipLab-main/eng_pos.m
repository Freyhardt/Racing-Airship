function trl = eng_pos(axis,part)
global ls;
switch axis(1)
    case 1
        edit_name = 'edit_eng_x';
        slider_name = 'slider_eng_x';
        field = 'pos_x';
        min = -0.2;
        max = 1.2;
    case 2
        edit_name = 'edit_eng_y';
        slider_name = 'slider_eng_y';
        field = 'pos_y';
        min = -2;
        max = 2;
    case 3
        edit_name = 'edit_eng_z';
        slider_name = 'slider_eng_z';
        field = 'pos_z';
        min = -2;
        max = 2;
end
if part > 6
    eng = ['eng' num2str(axis(1))];
else
    eng = ['eng' num2str(ls.mass.eng)];
end
switch part
    case 1
        edit = str2double(get(ls.handles.start.ha.(edit_name),'String'));
        set(ls.handles.start.ha.(slider_name),'Value',edit);
        ls.mass.(eng).(field) = edit;
        eng_pos([ls.mass.eng ls.mass.(eng).pos_x],8);
        name = ['edit_eng' num2str(ls.mass.eng) '_relpos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).pos_x);
    case 2
        slider = get(ls.handles.start.ha.(slider_name),'Value');
        set(ls.handles.start.ha.(edit_name),'String',num2str(slider));
        ls.mass.(eng).(field) = slider;
        name = ['edit_eng' num2str(ls.mass.eng) '_relpos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).pos_x);
        eng_pos([ls.mass.eng ls.mass.(eng).pos_x],8);
    case 3
        set(ls.handles.start.ha.edit_eng_x,'String',num2str(ls.mass.(eng).pos_x));
        set(ls.handles.start.ha.edit_eng_y,'String',num2str(ls.mass.(eng).pos_y));
        set(ls.handles.start.ha.edit_eng_z,'String',num2str(ls.mass.(eng).pos_z));
        set(ls.handles.start.ha.slider_eng_x,'Value',ls.mass.(eng).pos_x);
        set(ls.handles.start.ha.slider_eng_y,'Value',ls.mass.(eng).pos_y);
        set(ls.handles.start.ha.slider_eng_z,'Value',ls.mass.(eng).pos_z);
        set(ls.handles.start.ha.check_eng_dynprop,'Value',ls.mass.(eng).dynprop);
        set(ls.handles.start.ha.edit_eng_propmin,'String',num2str(ls.mass.(eng).minprop));
        set(ls.handles.start.ha.edit_eng_propmax,'String',num2str(ls.mass.(eng).maxprop));
    case 4
        if ls.mass.(eng).dynprop == 0
            ls.mass.multi_prop = 0;
            ls.mass.(eng).dynprop = 1;
            ls.perf.prop_min = ls.mass.(eng).minprop;
            ls.perf.prop_max = ls.mass.(eng).maxprop;
            propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
            ls.mass.(eng).prop = ls.perf.prop_opt;
            name = ['edit_eng' num2str(ls.mass.eng) '_prop'];
            set(ls.handles.start.ha.(name),'String',ls.mass.(eng).prop);
        else
            ls.mass.(eng).dynprop = 0;
            ls.mass.multi_prop = 1;
            propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
        end
        set(ls.handles.start.ha.check_eng_dynprop,'Value',ls.mass.(eng).dynprop);
        
    case 5
        ls.mass.(eng).minprop = axis(1);
        if ls.mass.(eng).dynprop == 1
            ls.perf.prop_min = ls.mass.(eng).minprop;
            propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
            ls.mass.(eng).prop = ls.perf.prop_opt;
            name = ['edit_eng' num2str(ls.mass.eng) '_prop'];
            set(ls.handles.start.ha.(name),'String',ls.mass.(eng).prop);
        end
    case 6
        ls.mass.(eng).maxprop = axis(1);
        if ls.mass.(eng).dynprop == 1
            ls.perf.prop_max = ls.mass.(eng).maxprop;
            propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
            ls.mass.(eng).prop = ls.perf.prop_opt;
            name = ['edit_eng' num2str(ls.mass.eng) '_prop'];
            set(ls.handles.start.ha.(name),'String',ls.mass.(eng).prop);
        end
    case 7
        ls.mass.(eng).pos_x = axis(2)/ls.geometry.length;
        name = ['edit_eng' num2str(axis(1)) '_relpos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).pos_x);
        eng_pos(1,3);
    case 8
        ls.mass.(eng).abspos = axis(2)*ls.geometry.length;
        name = ['edit_eng' num2str(axis(1)) '_abspos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).abspos);
        ls.mass.(eng).pos_x = axis(2);
        eng_pos(1,3);
    case 9
        ls.mass.(eng).power = axis(2);
        mass_eng(axis(1),1);
        ls.mass.multi_prop = 1;
        propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
    case 10
        ls.mass.(eng).prop = axis(2);
        mass_eng(axis(1),1);
        ls.mass.multi_prop = 1;
        propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
    case 11
        ls.mass.(eng).mass = axis(2);
    case 12
        ls.mass.(eng).eff = axis(2);
        mass_eng(axis(1),1);
        ls.mass.multi_prop = 1;
        propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
end
totalmass(1);
trim();