function ghl = mass_control(eng, pos)
global ls;
mass_name = ['edit_control' num2str(eng) '_mass'];
relpos_name = ['edit_control' num2str(eng) '_relpos'];
abspos_name = ['edit_control' num2str(eng) '_abspos'];
power_name = ['edit_control' num2str(eng) '_power'];
eff_name = ['edit_control' num2str(eng) '_eff'];
prop_name = ['edit_control' num2str(eng) '_prop'];
if pos == 1
    name = ['check_control' num2str(eng)];
    on = get(ls.handles.start.ha.(name),'Value');
    ls.mass.controlon(eng) = on;
    if on == 1
        set(ls.handles.start.ha.(mass_name),'Enable','on');
        set(ls.handles.start.ha.(relpos_name),'Enable','on');
        set(ls.handles.start.ha.(abspos_name),'Enable','on');
    else
        set(ls.handles.start.ha.(mass_name),'Enable','off');
        set(ls.handles.start.ha.(relpos_name),'Enable','off');
        set(ls.handles.start.ha.(abspos_name),'Enable','off');
    end
end
totalmass(1);
trim;