function shape_radius = hullpos(x) %gives the hulldiameter on a specific x-coordinate
global ls;
if x <= 0 || x >= ls.geometry.length
    shape_radius = 0;
else
if ls.geometry.set == 1
    x = x / ls.geometry.length;
    shape_radius = 1/ls.geometry.l2d*sqrt(ls.gertler.coef(1)*x + ls.gertler.coef(2)*x.^2 + ls.gertler.coef(3)*x.^3 + ...
    ls.gertler.coef(4)*x.^4 + ls.gertler.coef(5)*x.^5 + ls.gertler.coef(6)*x.^6);
    shape_radius = shape_radius * ls.geometry.length;
else
    next = find(ls.geometry.shape > x, 1);
    shape_radius = (ls.geometry.shape(next-1) + ls.geometry.shape(next) ) / 2;
end
end