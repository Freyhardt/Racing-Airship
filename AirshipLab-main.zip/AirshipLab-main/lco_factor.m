function lco = lco_factor(c_max)
lco = 179.58*c_max^3 - 117.81*c_max^2 + 25.18 * c_max + 1.6;