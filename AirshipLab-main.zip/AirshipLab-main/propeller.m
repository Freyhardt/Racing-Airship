function result = propeller(leistung)
global ls;
prop_min = ls.perf.prop_min;
prop_max = ls.perf.prop_max;
rho = ls.aerodyn.rho;
steps2 = ls.perf.itersteps;
steps = steps2;
p_max = leistung;
  if prop_min == prop_max || ls.mass.multi_prop == 1
      prop = ls.perf.prop_dia;
      steps = 1;
  else
      prop = prop_min:(prop_max-prop_min)/(steps-1):prop_max;
  end
  name = ['eng' num2str(ls.mass.eng)];
if  ls.mass.multi_prop == 1
    prop = ls.mass.(name).prop;
    steps = 1;
end
x = 0;
y = 0;
for t = 1:steps
  A(t) = (prop(t)/2)^2*pi();
    p_neu = 0;
    v_2 = 0;
    v_2 = ((4 * p_max)/(A(t) * rho))^(1/3)*0.95;
    while p_neu < p_max
        v_2 = v_2 + 0.001;
        p_alt = 0;
        gradient = 1;
        v_1 = v_2/3;
        y = y + 1;
        p_neu = A(t) * rho/4 * (v_1+v_2) * (v_2^2 - v_1^2);

    end
    x;
    y;
handi(t) = v_2;
end
v_2 = handi;
z = 0;
for t = 1:steps
    if steps == 1
        steps = steps2;
    end
    v_1 = 0;
    drag2 = -1;
    thrust = 0;
    while drag2 <= thrust
            v_1 = v_1 + v_2(t)/500;%(steps-1);
            drag2 = aerodyn(v_1, ls.settings.aerometh);
            thrust = A(t)*rho/2*(v_2(t).^2-v_1^2);
            z = z + 1;
    end
    v_max(t) = v_1;
end
z;
[ls.aerodyn.v_max,y] = max(v_max);
ls.perf.v_max = ls.aerodyn.v_max;
ls.perf.prop_opt = 2*sqrt(A(y)/pi);
ls.perf.v2 = v_2(y);
maxthrust = A(y)*rho/2*(v_2(y)^2);
ls.perf.(name).v2 = ls.perf.v2;
%v2_neu = ls.perf.(name).v2
ls.perf.maxthrust = maxthrust;
if ls.mass.multi_prop == 0  && ls.settings.iter == 0
set(ls.handles.start.ha.edit_v_max,'String',num2str(ls.aerodyn.v_max));
set(ls.handles.start.ha.edit_v2,'String',num2str(v_2(y)));
set(ls.handles.start.ha.edit_prop_opt,'String',num2str(ls.perf.prop_opt));
set(ls.handles.start.ha.edit_thrust_vmax,'String',num2str(thrust));
set(ls.handles.start.ha.edit_thrust,'String',num2str(maxthrust));
end
