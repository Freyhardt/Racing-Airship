function returning = schubdiagramm()
global test; 
for v_1 = 0:0.01:25
    speed = round(abs(v_1 * 100 + 1));
    step = speed;
    v_1;
    drag(step) = aerodyn(v_1,1);
end
test = v_1;
v_1 = 0:0.01:25;
d1 = 0.077778;
d2 = 0.05;
d3 = 0.15;
v_2 = [18.0629 24.2497 11.6586];
A1 = (d1/2)^2*pi;
A2 = (d2/2)^2*pi;
A3 = (d3/2)^2*pi;
%P = A1 * 1.225/4 *(v_2(1) + v_2(1)/3)*(v_2(1)^2 - (v_2(1)/3)^2);
Schub1 = 1.225/2*A1*(v_2(1)^2 - (v_1(1:(v_2(1))*100+1)).^2);
Schub2 = 1.225/2*A2*(v_2(2)^2 - (v_1(1:(v_2(2))*100+1)).^2);
Schub3 = 1.225/2*A3*(v_2(3)^2 - (v_1(1:(v_2(3))*100+1)).^2);
hold on; 
v_x = v_1(1:(v_2(1))*100+1);
plot(v_x, Schub1, 'r');
v_x = v_1(1:(v_2(2))*100+1);
plot(v_x, Schub2, 'k');
v_x = v_1(1:(v_2(3))*100+1);
plot(v_x, Schub3, 'b');
% plot(v_2(2), Schub2);
% plot(v_2(3), Schub3);
v_max = max(v_2);
v_x = v_1(1:(v_max)*100+1);
plot(v_x, drag(1:v_max*100+1), 'Color', [1 0 0]);
%returning = [v_x;Schub1];