function cosine()
n = 100;
m = 0:n
i = 0:n-1;
test = n./i
phi = pi()*test.^(-1);
x = (1-cos(phi))/2