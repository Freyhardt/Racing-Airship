function checker = perfview(view)
global ls;
cla;
    if ls.perf.view(view) == 1
        ls.perf.view(view) = 0;
    else
        ls.perf.view(view) = 1;
    end
    if view == 1
        for view = 2:4
        ls.perf.view(view) = 0;
        field = ['check_view' num2str(view)];
        set(ls.handles.start.ha.(field),'Value',0);
        end
    else
        set(ls.handles.start.ha.check_view1,'Value',0);
        ls.perf.view(1) = 0;
    end
if ls.perf.view(1) == 1
    volumen();
end
hold on;
z = 0:ls.perf.v2/100:ls.perf.v2;
if ls.perf.view(2) == 1
    for y = 0:100
        T(y+1) = aerodyn(y*ls.perf.v2/100, ls.settings.aerometh);
    end
    plot(z,T,'b');
end
if ls.perf.view(3) == 1
    T = ls.aerodyn.rho/2 * ls.perf.prop_opt^2/4*pi *(ls.perf.v2.^2 - z.^2);
    plot(z,T,'g');
end
if ls.perf.view(4) == 1
    for y = 0:100
        part = (ls.perf.v2.^2 - z.^2);
        T = ls.aerodyn.rho/4 * ls.perf.prop_opt^2/4*pi * part.* (z + ls.perf.v2) * ls.perf.scale_power;
    end
    plot(z,T,'r');
end
hold off;
if ls.perf.view(1) ~= 1
    y_range = [ls.perf.maxthrust ls.perf.power*ls.perf.scale_power];
    axis([0 ls.perf.v2 0 max(y_range)+max(y_range)*0.1]);
end
    
            
            
