function k = k_factor(l2d)
k = 1.9167*l2d^5-5.9085*l2d^4+6.8938*l2d^3-3.5647*l2d^2-0.3374*l2d+1;