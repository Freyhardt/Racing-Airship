function shape = gertler(r0,r1,cp,m,l2d,stuetz)
global ls;
A = [1 0 0 0 0 0; 1 1 1 1 1 1; m m.^2 m.^3 m.^4 m.^5 m.^6; 1 2*m 3*m.^2 ...
    4*m.^3 5*m.^4 6*m.^5; 1 2 3 4 5 6; 1/2 1/3 1/4 1/5 1/6 1/7];
x = [2*r0; 0; 1/4; 0; -2*r1; 1/4*cp];
gert = inv(A)*x;
ls.gertler.coef = gert;
if ls.settings.dim == 1
    st = 0:(stuetz-1);
    t = st./(stuetz-1);
else
    n = stuetz;
    i = 0:n-1;
    test = n./(i+1);
    phi = pi()*test.^(-1);
    t = (1-cos(phi))/2;
    t(1) = 0;
end
shape = 1/l2d*sqrt(gert(1)*t + gert(2)*t.^2 + gert(3)*t.^3 + ...
    gert(4)*t.^4 + gert(5)*t.^5 + gert(6)*t.^6);
shape = [t;shape];
