function preview(t)
global ls;
switch t
    case 1
        if ls.settings.dim == 1
            ls.settings.dim = 0;
            set(ls.handles.start.ha.radio_3D,'Value',0);
        else
            set(ls.handles.start.ha.radio_3D,'Value',1);
            ls.settings.dim = 1;
        end
        volumen();
        drawing();
    case 2
        if ls.settings.dim == 0
            ls.settings.dim = 1;
            set(ls.handles.start.ha.radio_2D,'Value',0);
        else
            set(ls.handles.start.ha.radio_2D,'Value',1);
            ls.settings.dim = 0;
        end
        volumen();
        drawing();
end