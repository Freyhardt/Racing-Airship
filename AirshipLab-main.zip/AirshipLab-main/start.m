function varargout = start(varargin)

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @start_OpeningFcn, ...
                   'gui_OutputFcn',  @start_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function start_OpeningFcn(hObject, eventdata, handles, varargin)
global ls;
ls.handles.start.ha = handles;
ls.handles.start.hO = hObject;
ls.handles.start.ev = eventdata;
definition_function();
axis equal;
volumen();
ltw_set(4);
aerodyn(10,1);
propeller(ls.perf.power);
handles.output = hObject;

guidata(hObject, handles);

function varargout = start_OutputFcn(hObject, eventdata, handles) 

varargout{1} = handles.output;

%=========================================================================
%==================Callbacks==============================================
%=========================================================================

% Menu Buttons
function button_overview_Callback(hObject, eventdata, handles)
sheetset(1);


function slider1_Callback(hObject, eventdata, handles)


function button_shape_Callback(hObject, eventdata, handles)
sheetset(2);
volumen();


function button_performance_Callback(hObject, eventdata, handles)
sheetset(3);
global ls;
ls.mass.multi_prop = 0;
if ls.settings.dynprop == 1
    propeller(ls.perf.power);
end


function button_masses_Callback(hObject, eventdata, handles)
sheetset(4);
totalmass(1);
trim();

function button_sternplain_Callback(hObject, eventdata, handles)
ltw_set(4);
sheetset(5);

function button_iter_Callback(hObject, eventdata, handles)
iteration();

function button_save_Callback(hObject, eventdata, handles)
global ls;
[file,path] = uiputfile('.mat','Projekt exportieren...');
exportfile = ls;
saveat = [path file];
save(saveat, 'ls');
disp('File Saved');

function button_load_Callback(hObject, eventdata, handles)
global ls;
sheetset(1);
savehandles = ls.handles;
[file,path] = uigetfile('.mat','Projekt importieren...');
loadfrom = strcat(path, file);
neu = load(loadfrom);
ls = neu.ls;
ls.handles = savehandles;
sheetset(1);
loadfile();


function button_center_Callback(hObject, eventdata, handles)
axes(handles.display);
axis equal;


function button_grid_Callback(hObject, eventdata, handles)
global ls;
if ls.settings.grid == 0;
    grid on;
    ls.settings.grid = 1;
else
    grid off;
    ls.settings.grid = 0;
end


function shapeselect_Callback(hObject, eventdata, handles)
varis = get(hObject,'Value');
gertler_daten(varis);

% Envelope Parameters
function edit_length_Callback(hObject, eventdata, handles)
global ls;
ls.geometry.length = str2num(get(handles.edit_length,'string'));
ls.geometry.thick = ls.geometry.length/ls.geometry.l2d;
set(handles.edit_thickness,'String',num2str(ls.geometry.thick));
volumen();


function edit_thickness_Callback(hObject, eventdata, handles)
global ls;
ls.geometry.think = str2num(get(handles.edit_thickness,'string'));
ls.geometry.length = ls.geometry.thick*ls.geometry.l2d;
set(handles.edit_length,'String',num2str(ls.geometry.length));
volumen();


function edit_l2d_Callback(hObject, eventdata, handles)
global ls;
volum = ls.geometry.volume;
ls.geometry.l2d = str2num(get(handles.edit_l2d,'string'));
ls.geometry.thick = ls.geometry.length/ls.geometry.l2d;
set(handles.edit_thickness,'String',num2str(ls.geometry.thick));
volumen();
ls.geometry.volume = volum;
volumen();


function slider2_Callback(hObject, eventdata, handles)


function edit_volume_Callback(hObject, eventdata, handles)
global ls;
ls.geometry.volume = str2num(get(handles.edit_volume,'string'));
volumen();

function edit_ltw_surface_Callback(hObject, eventdata, handles)


function listbox1_Callback(hObject, eventdata, handles)


function edit_surface2_Callback(hObject, eventdata, handles)


function slider_r0_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.r0 = get(handles.slider_r0,'Value');
set(handles.edit_r0,'String',num2str(ls.gertler.r0));
volumen();


function slider_r1_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.r1 = get(handles.slider_r1,'Value');
set(handles.edit_r1,'String',num2str(ls.gertler.r1));
volumen();


function slider_cp_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.cp = get(handles.slider_cp,'Value');
set(handles.edit_cp,'String',num2str(ls.gertler.cp));
volumen();


function slider_m_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.m = get(handles.slider_m,'Value');
set(handles.edit_m,'String',num2str(ls.gertler.m));
volumen();


function edit_r0_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.r0 = str2num(get(handles.edit_r0,'String'));
set(handles.slider_r0,'Value',(ls.gertler.r0));
volumen();


function edit_r1_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.r1 = str2num(get(handles.edit_r1,'String'));
set(handles.slider_r1,'Value',(ls.gertler.r1));
volumen();


function edit_cp_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.cp = str2num(get(handles.edit_cp,'String'));
set(handles.slider_cp,'Value',(ls.gertler.cp));
volumen();


function edit_m_Callback(hObject, eventdata, handles)
global ls;
ls.gertler.m = str2num(get(handles.edit_m,'String'));
set(handles.slider_m,'Value',(ls.gertler.m));
volumen();


function edit_vsp_Callback(hObject, eventdata, handles)


function edit_dots_Callback(hObject, eventdata, handles)
global ls;
ls.geometry.dots = str2num(get(handles.edit_dots,'String'));
volumen();


function button_import_Callback(hObject, eventdata, handles)
shapeload();

function button_export_Callback(hObject, eventdata, handles)
global ls;
[file,path] = uiputfile(ls.settings.export,'Shape exportieren...');
exportfile = ls.geometry.shape;
xlswrite([path file], exportfile);


function edit_headlines_Callback(hObject, eventdata, handles)
global ls;
ls.settings.headline = str2num(get(handles.edit_headline,'String'));


function edit_dimention_Callback(hObject, eventdata, handles)
global ls;
ls.settings.dimension = str2num(get(handles.edit_dimension,'String'));


function exportfile_Callback(hObject, eventdata, handles)
global ls;
varis1 = get(hObject,'Value');
switch varis1
    case 1
        ls.settings.export = '.xls';
    case 2
        ls.settings.export = '.xlsx';
end


function edit_density_air_Callback(hObject, eventdata, handles)


function edit_density_he_Callback(hObject, eventdata, handles)


function edit_k_air_Callback(hObject, eventdata, handles)
global ls;
ls.aerostat.r_air = str2num(get(handles.edit_k_air,'String'));
aerostats();


function gasmenu_Callback(hObject, eventdata, handles)
varis1 = get(hObject,'Value');
gasselect(varis1);


function edit_k_he_Callback(hObject, eventdata, handles)
global ls;
ls.aerostat.r_he = str2num(get(handles.edit_k_he,'String'));
aerostats();


function edit_p_air_Callback(hObject, eventdata, handles)
pressureselect(1);
aerostats();


function edit_p_he_Callback(hObject, eventdata, handles)
pressureselect(2);
aerostats();


function edit_p_delta_Callback(hObject, eventdata, handles)
pressureselect(3);
aerostats();


function edit_t_air_Callback(hObject, eventdata, handles)
tempinput(1);
aerostats;


function edit_t_he_Callback(hObject, eventdata, handles)
tempinput(2);
aerostats();


function edit_t_delta_Callback(hObject, eventdata, handles)
tempinput(3);
aerostats();


function temp_unit_Callback(hObject, eventdata, handles)
varis1 = get(hObject,'Value');
tempunit(varis1);


function edit_lift_kg_Callback(hObject, eventdata, handles)


function edit_lift_n_Callback(hObject, eventdata, handles)


function edit_lift_spec_Callback(hObject, eventdata, handles)


function atmosphere_Callback(hObject, eventdata, handles)
atmos_set = get(hObject,'Value');
atmosphereset(atmos_set);

function edit_hull_cuts_Callback(hObject, eventdata, handles)
hull_material(1);

function button_export_cuts_Callback(hObject, eventdata, handles)
hull_material(3);

function menu_hull_material_Callback(hObject, eventdata, handles)
hull_material(5);

function edit_cuts_overlay_Callback(hObject, eventdata, handles)
hull_material(2);

function menu_hull_material_CreateFcn(hObject, eventdata, handles)

function edit_mass_per_m2_Callback(hObject, eventdata, handles)
hull_material(4);

function check_cuts_view_Callback(hObject, eventdata, handles)
hull_material(6);

function checkbox4_Callback(hObject, eventdata, handles)

% Perfomance Page %%

function edit_power_Callback(hObject, eventdata, handles)
global ls;
ls.perf.power = str2double(get(handles.edit_power,'String'));
propeller(ls.perf.power);


function thrust_menu_Callback(hObject, eventdata, handles)


function edit_propdia_Callback(hObject, eventdata, handles)
global ls;
ls.perf.prop_dia = str2double(get(handles.edit_propdia,'String'));
ls.perf.prop_min = ls.perf.prop_dia;
ls.perf.prop_max = ls.perf.prop_dia;
propeller(ls.perf.power);


function edit_interference_Callback(hObject, eventdata, handles)
global ls;
speed = str2num(get(handles.edit_speedselect,'String'));
ls.aerodyn.interference = str2num(get(handles.edit_interference,'String'));
vari = aerodyn(speed, ls.settings.aerometh);
set(handles.edit_totaldrag,'String',num2str(vari));
set(handles.edit_ltwdrag,'String',ls.ltw.drag);


function edit_speedselect_Callback(hObject, eventdata, handles)
global ls;
speed = str2num(get(handles.edit_speedselect,'String'));
vari = aerodyn(speed, ls.settings.aerometh);
set(handles.edit_totaldrag,'String',num2str(vari));
set(handles.edit_ltwdrag,'String',ls.ltw.drag);


function edit_totaldrag_Callback(hObject, eventdata, handles)


function edit_ltwdrag_Callback(hObject, eventdata, handles)


function edit_prop_min_Callback(hObject, eventdata, handles)
global ls;
ls.perf.prop_min = str2double(get(handles.edit_prop_min,'String'));
ls.perf.prop_max = str2double(get(handles.edit_prop_max,'String'));
propeller(ls.perf.power);


function edit_prop_max_Callback(hObject, eventdata, handles)
global ls;
ls.perf.prop_max = str2double(get(handles.edit_prop_max,'String'));
ls.perf.prop_min = str2double(get(handles.edit_prop_min,'String'));
propeller(ls.perf.power);


function edit_v2_Callback(hObject, eventdata, handles)


function check_dynprop_Callback(hObject, eventdata, handles)
global ls;
if ls.settings.dynprop == 1
    set(handles.edit_prop_min,'Enable','off');
    set(handles.edit_prop_max,'Enable','off');
    set(handles.edit_propdia,'Enable','on');
    set(handles.edit_itersteps,'Enable','off');
    ls.settings.dynprop = 0;
    ls.perf.prop_min = ls.perf.prop_dia;
    ls.perf.prop_max = ls.perf.prop_dia;
else
    set(handles.edit_prop_min,'Enable','on');
    set(handles.edit_prop_max,'Enable','on');
    set(handles.edit_propdia,'Enable','off');
    set(handles.edit_itersteps,'Enable','on');
    ls.settings.dynprop = 1;
    ls.perf.prop_max = str2double(get(handles.edit_prop_max,'String'));
    ls.perf.prop_min = str2double(get(handles.edit_prop_min,'String'));
end
propeller(ls.perf.power);


function edit_prop_opt_Callback(hObject, eventdata, handles)


function edit_v_max_Callback(hObject, eventdata, handles)

function edit_thrust_vmax_Callback(hObject, eventdata, handles)

function edit_thrust_Callback(hObject, eventdata, handles)


function edit_itersteps_Callback(hObject, eventdata, handles)
global ls;
ls.perf.itersteps = str2double(get(handles.edit_itersteps,'String'));
propeller(ls.perf.power);

function check_view1_Callback(hObject, eventdata, handles)
perfview(1);


function check_view2_Callback(hObject, eventdata, handles)
perfview(2);

function check_view3_Callback(hObject, eventdata, handles)
perfview(3);

function check_view4_Callback(hObject, eventdata, handles)
perfview(4);


function checkbox11_Callback(hObject, eventdata, handles)


function edit_scale_power_Callback(hObject, eventdata, handles)
global ls;
ls.perf.scale_power = str2double(get(handles.edit_scale_power,'String'));
perfview(5);


function edit_scale_power_CreateFcn(hObject, eventdata, handles)

%=============Masses===================

function check_eng1_Callback(hObject, eventdata, handles)

function check_engi1_Callback(hObject, eventdata, handles)
mass_eng(1,1);

function check_engi2_Callback(hObject, eventdata, handles)
mass_eng(2,1);

function check_engi3_Callback(hObject, eventdata, handles)
mass_eng(3,1);

function check_engi4_Callback(hObject, eventdata, handles)
mass_eng(4,1);

function edit_eng1_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng1,'String'));
eng_pos([1 value],11);

function edit_eng2_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng2,'String'));
eng_pos([2 value],11);

function edit_eng3_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng3,'String'));
eng_pos([3 value],11);

function edit_eng4_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng4,'String'));
eng_pos([4 value],11);

function edit_eng1_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng1_relpos,'String'));
eng_pos([1 value] ,8);

function edit_eng2_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng2_relpos,'String'));
eng_pos([2 value] ,8);

function edit_eng3_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng3_relpos,'String'));
eng_pos([3 value] ,8);

function edit_eng4_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng4_relpos,'String'));
eng_pos([4 value] ,8);

function edit_eng1_power_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng1_power,'String'));
eng_pos([1 value] ,9);

function edit_eng2_power_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng2_power,'String'));
eng_pos([2 value] ,9);

function edit_eng3_power_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng3_power,'String'));
eng_pos([3 value] ,9);

function edit_eng4_power_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng4_power,'String'));
eng_pos([4 value] ,9);

function edit_eng1_eff_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng1_eff,'String'));
eng_pos([1 value] ,12);

function edit_eng2_eff_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng2_eff,'String'));
eng_pos([2 value] ,12);

function edit_eng3_eff_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng3_eff,'String'));
eng_pos([3 value] ,12);

function edit_eng4_eff_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng4_eff,'String'));
eng_pos([4 value] ,12);

function edit_eng1_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng1_abspos,'String'));
eng_pos([1 value] ,7);

function edit_eng2_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng2_abspos,'String'));
eng_pos([2 value] ,7);

function edit_eng3_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng3_abspos,'String'));
eng_pos([3 value] ,7);

function edit_eng4_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng4_abspos,'String'));
eng_pos([4 value] ,7);

function edit_eng1_prop_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng1_prop,'String'));
eng_pos([1 value] ,10);

function edit_eng2_prop_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng2_prop,'String'));
eng_pos([2 value] ,10);

function edit_eng4_prop_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng4_prop,'String'));
eng_pos([4 value] ,10);

function edit_eng3_prop_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_eng3_prop,'String'));
eng_pos([3 value] ,10);

function edit_eng_x_Callback(hObject, eventdata, handles)
eng_pos(1,1);

function slider_eng_x_Callback(hObject, eventdata, handles)
eng_pos(1,2);

function edit_eng_y_Callback(hObject, eventdata, handles)
eng_pos(2,1);

function slider_eng_y_Callback(hObject, eventdata, handles)
eng_pos(2,2);

function menu_eng_Callback(hObject, eventdata, handles)
global ls;
ls.mass.eng = get(hObject,'Value');
eng_pos(1,3);

function check_eng_dynprop_Callback(hObject, eventdata, handles)
send = get(handles.check_eng_dynprop,'Value');
eng_pos(send,4);

function edit_eng_z_Callback(hObject, eventdata, handles)
eng_pos(3,1);

function slider_eng_z_Callback(hObject, eventdata, handles)
eng_pos(3,2);

function edit_eng_propmin_Callback(hObject, eventdata, handles)
send = str2double(get(handles.edit_eng_propmin,'String'));
eng_pos(send,5);

function edit_eng_propmax_Callback(hObject, eventdata, handles)
send = str2double(get(handles.edit_eng_propmax,'String'));
eng_pos(sned,6);

function check_control1_Callback(hObject, eventdata, handles)
mass_control(1,1);

function check_control2_Callback(hObject, eventdata, handles)
mass_control(2,1);

function check_control3_Callback(hObject, eventdata, handles)
mass_control(3,1);

function check_control4_Callback(hObject, eventdata, handles)
mass_control(4,1);

function edit_control1_mass_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control1_mass,'String'));
control_pos([1 value] ,4);

function edit_control2_mass_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control2_mass,'String'));
control_pos([2 value] ,4);

function edit_control3_mass_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control3_mass,'String'));
control_pos([3 value] ,4);

function edit_control4_mass_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control4_mass,'String'));
control_pos([4 value] ,4);

function edit_control1_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control1_relpos,'String'));
control_pos([1 value] ,8);

function edit_control2_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control2_relpos,'String'));
control_pos([2 value] ,8);

function edit_control3_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control3_relpos,'String'));
control_pos([3 value] ,8);

function edit_control4_relpos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control4_relpos,'String'));
control_pos([4 value] ,8);

function edit_control1_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control1_abspos,'String'));
control_pos([1 value] ,7);

function edit_control2_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control2_abspos,'String'));
control_pos([2 value] ,7);

function edit_control3_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control3_abspos,'String'));
control_pos([3 value] ,7);

function edit_control4_abspos_Callback(hObject, eventdata, handles)
value = str2double(get(handles.edit_control4_abspos,'String'));
control_pos([4 value] ,7);

function menu_control_Callback(hObject, eventdata, handles)
global ls;
ls.mass.control = get(hObject,'Value');
control_pos(1,3);

function edit_control_posx_Callback(hObject, eventdata, handles)
control_pos(1,1);

function slider_control_posx_Callback(hObject, eventdata, handles)
control_pos(1,2);

function edit_control_posy_Callback(hObject, eventdata, handles)
control_pos(2,1);

function slider_control_posy_Callback(hObject, eventdata, handles)
control_pos(2,2);

function edit_control_posz_Callback(hObject, eventdata, handles)
control_pos(3,1);

function slider_control_posz_Callback(hObject, eventdata, handles)
control_pos(3,2);

function button_servo_add_Callback(hObject, eventdata, handles)
servo_mass(0, 5);
       
function button_servo_remove_Callback(hObject, eventdata, handles)
servo_mass(0, 6);

function edit_servo_relx_Callback(hObject, eventdata, handles)
servo_mass(1 ,1);

function edit_servo_rely_Callback(hObject, eventdata, handles)
servo_mass(2, 1);

function edit_servo_relz_Callback(hObject, eventdata, handles)
servo_mass(3, 1);

function edit_servo_absx_Callback(hObject, eventdata, handles)
servo_mass(1, 3);

function edit_servo_absy_Callback(hObject, eventdata, handles)
servo_mass(2, 3);

function edit_servo_absz_Callback(hObject, eventdata, handles)
servo_mass(3, 3);

function slider_servo_x_Callback(hObject, eventdata, handles)
servo_mass(1, 2);

function slider_servo_y_Callback(hObject, eventdata, handles)
servo_mass(2, 2);

function slider_servo_z_Callback(hObject, eventdata, handles)
servo_mass(3, 2);

function menu_servoselect_Callback(hObject, eventdata, handles)
global ls;
ls.mass.servo.selection = get(hObject,'Value');
check = get(ls.handles.start.ha.menu_servoselect,'String');
ls.mass.servo = str2double(check(ls.mass.servo.selection,7:8));
servo_mass(0, 4);

function check_servoconnect_Callback(hObject, eventdata, handles)
servo_mass(0, 9);

function menu_servoconnect_Callback(hObject, eventdata, handles)

function edit_servo_mass_Callback(hObject, eventdata, handles)
servo_mass(0, 7);

function edit_servo_rel_ltw_Callback(hObject, eventdata, handles)

function edit_payload1_mass_Callback(hObject, eventdata, handles)
payload_mass(1, 1);

function edit_payload2_mass_Callback(hObject, eventdata, handles)
payload_mass(2, 1);

function edit_accu_mass_Callback(hObject, eventdata, handles)
payload_mass(3, 1);

function edit_trim_mass_Callback(hObject, eventdata, handles)
payload_mass(5, 1);

function edit_receiver_mass_Callback(hObject, eventdata, handles)
payload_mass(4, 1);


function edit_payload1_relpos_Callback(hObject, eventdata, handles)
payload_mass(1, 2);

function edit_payload2_relpos_Callback(hObject, eventdata, handles)
payload_mass(2, 2);

function edit_accu_relpos_Callback(hObject, eventdata, handles)
payload_mass(3, 2);

function edit_trim_relpos_Callback(hObject, eventdata, handles)
payload_mass(5, 2);

function edit_receiver_relpos_Callback(hObject, eventdata, handles)
payload_mass(4, 2);

function edit_payload1_abspos_Callback(hObject, eventdata, handles)
payload_mass(1, 3);

function edit_payload2_abspos_Callback(hObject, eventdata, handles)
payload_mass(2, 3);

function edit_accu_abspos_Callback(hObject, eventdata, handles)
payload_mass(3, 3);

function edit_trim_abspos_Callback(hObject, eventdata, handles)
payload_mass(5, 3);

function edit_receiver_abspos_Callback(hObject, eventdata, handles)
payload_mass(4, 3);

function edit_eng_cable_rel_mass_Callback(hObject, eventdata, handles)
cable_set();
function edit_servo_cable_mass_Callback(hObject, eventdata, handles)

function edit_servo_cable_rel_mass_Callback(hObject, eventdata, handles)
cable_set();

function edit_eng_cable_mass_Callback(hObject, eventdata, handles)

function edit_ltw_mass_Callback(hObject, eventdata, handles)

function edit_hull_mass_Callback(hObject, eventdata, handles)

function edit_mass_Callback(hObject, eventdata, handles)
payload_mass(0, 9);


function edit_mass_reserve_Callback(hObject, eventdata, handles)
payload_mass(0, 5);
totalmass(0);

function check_mass_varibat_Callback(hObject, eventdata, handles)
on = get(handles.check_mass_varibat,'Value');
payload_mass(on, 6);

function edit_mass_varibat_from_Callback(hObject, eventdata, handles)
payload_mass(0, 7);

function edit_mass_varibat_to_Callback(hObject, eventdata, handles)
payload_mass(0, 8);

%      Sternplains

function menu_ltw_methode_Callback(hObject, eventdata, handles)
global ls;
ls.ltw.methode = get(hObject,'Value');
ltw_set(11);

function edit_ltw_area_Callback(hObject, eventdata, handles)

function edit154_Callback(hObject, eventdata, handles)

function edit_ltw_aspect_Callback(hObject, eventdata, handles)
ltw_set(2);

function edit_ltw_taper_Callback(hObject, eventdata, handles)
ltw_set(3);

function edit_ltw_span_Callback(hObject, eventdata, handles)

function edit_hull_moment_Callback(hObject, eventdata, handles)

function edit_hull_k_factor_Callback(hObject, eventdata, handles)

function edit_hull_alpha_Callback(hObject, eventdata, handles)

function edit_ltw_pos_Callback(hObject, eventdata, handles)
ltw_set(1);

function menu_ltw_pos_Callback(hObject, eventdata, handles)

function menu_ltw_material_Callback(hObject, eventdata, handles)
sternplain_material(get(hObject,'Value'));

function edit_ltw_m_per_m2_Callback(hObject, eventdata, handles)
sternplain_material(4);

function edit_ltw_phi25_Callback(hObject, eventdata, handles)
ltw_set(5);

function edit_ltw_phi100_Callback(hObject, eventdata, handles)
ltw_set(6);

function check_ltw_opt_Callback(hObject, eventdata, handles)
ltw_set(8);

function edit_ltw_added_mass_Callback(hObject, eventdata, handles)
ltw_set(9);

function edit_ltw_percent_add_mass_Callback(hObject, eventdata, handles)
ltw_set(10);

function edit_ltw_ratio_hltw_Callback(hObject, eventdata, handles)
ltw_set(7);

function radio_2D_Callback(hObject, eventdata, handles)
preview(1);

function radio_3D_Callback(hObject, eventdata, handles)
preview(2);


% Create Function Part
% ========================================================================
%=========================================================================

function edit_eng_z_CreateFcn(hObject, eventdata, handles)

function slider1_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


function select_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_length_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_thickness_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_l2d_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider2_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_volume_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_surface_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function listbox1_CreateFcn(hObject, eventdata, handles)

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_surface2_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_r0_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function slider_r1_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function slider_cp_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function slider_m_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_r0_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_r1_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_cp_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_m_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_vsp_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_dots_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_headlines_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_dimention_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_prop_opt_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function exportfile_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_v2_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_prop_max_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_density_he_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_density_air_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_k_air_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function gasmenu_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_k_he_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_p_air_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_p_he_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_p_delta_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_t_air_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_t_he_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_t_delta_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function temp_unit_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_lift_kg_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_lift_n_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_lift_spec_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function atmosphere_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_power_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_interference_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_speedselect_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltwdrag_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_prop_min_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_totaldrag_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function thrust_menu_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_propdia_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_v_max_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_itersteps_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng1_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng1_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng1_power_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng1_eff_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng1_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng2_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng2_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng2_power_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng2_eff_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng2_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng3_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng3_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng3_power_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng3_eff_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng3_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng4_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng4_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng4_power_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng4_eff_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng4_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng1_prop_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng2_prop_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng3_prop_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng4_prop_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng_x_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_eng_x_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_eng_y_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_eng_y_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function menu_eng_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_eng_z_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_eng_propmin_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng_propmax_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_thrust_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_thrust_vmax_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control1_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control1_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control1_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control2_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control2_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control2_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control3_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control3_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control3_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control4_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control4_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control4_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control_posx_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_control_posx_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function menu_control_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_control_posz_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_control_posz_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_control_posy_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_control_posy_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_eng_cable_rel_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_cable_rel_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_relx_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_absx_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_servo_x_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_servo_rely_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_absy_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_servo_y_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit_servo_relz_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_absz_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function slider_servo_z_CreateFcn(hObject, eventdata, handles)

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function menu_servoselect_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function menu_servoconnect_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_rel_ltw_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_payload1_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_payload1_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_payload1_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_payload2_mass_CreateFcn(hObject, eventdata, handles)
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_payload2_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_payload2_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_accu_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_accu_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_accu_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_trim_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_trim_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_trim_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_receiver_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_receiver_relpos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_receiver_abspos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_hull_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_servo_cable_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_eng_cable_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_mass_reserve_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_mass_varibat_from_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_mass_varibat_to_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_area_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit154_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_aspect_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_taper_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_span_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_hull_moment_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_hull_k_factor_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_hull_alpha_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_pos_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function menu_ltw_pos_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% function edit162_Callback(hObject, eventdata, handles)
% 
% 
% function edit162_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit163_Callback(hObject, eventdata, handles)
% 
% 
% function edit163_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit164_Callback(hObject, eventdata, handles)
% 
% 
% function edit164_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit165_Callback(hObject, eventdata, handles)
% 
% 
% function edit165_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit166_Callback(hObject, eventdata, handles)
% 
% 
% function edit166_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit167_Callback(hObject, eventdata, handles)
% 
% 
% function edit167_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function popupmenu19_Callback(hObject, eventdata, handles)
% 
% 
% function popupmenu19_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: popupmenu controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit168_Callback(hObject, eventdata, handles)
% 
% 
% function edit168_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit169_Callback(hObject, eventdata, handles)
% 
% 
% function edit169_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% function edit170_Callback(hObject, eventdata, handles)
% 
% 
% function edit170_CreateFcn(hObject, eventdata, handles)
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end

function menu_ltw_material_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_m_per_m2_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_phi25_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_ltw_phi100_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit_ltw_added_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit_ltw_percent_add_mass_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_ltw_ratio_hltw_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit_mass_per_m2_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function menu_ltw_methode_CreateFcn(hObject, eventdata, handles)

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function edit_hull_cuts_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function edit_cuts_overlay_CreateFcn(hObject, eventdata, handles)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ltw_tip_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ltw_tip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ltw_tip as text
%        str2double(get(hObject,'String')) returns contents of edit_ltw_tip as a double


% --- Executes during object creation, after setting all properties.
function edit_ltw_tip_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ltw_tip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ltw_mid_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ltw_mid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ltw_mid as text
%        str2double(get(hObject,'String')) returns contents of edit_ltw_mid as a double


% --- Executes during object creation, after setting all properties.
function edit_ltw_mid_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ltw_mid (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ltw_root_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ltw_root (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ltw_root as text
%        str2double(get(hObject,'String')) returns contents of edit_ltw_root as a double


% --- Executes during object creation, after setting all properties.
function edit_ltw_root_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ltw_root (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_ltw_frontb_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ltw_frontb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ltw_frontb as text
%        str2double(get(hObject,'String')) returns contents of edit_ltw_frontb as a double


% --- Executes during object creation, after setting all properties.
function edit_ltw_frontb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ltw_frontb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit_ltw_backb_Callback(hObject, eventdata, handles)
% hObject    handle to edit_ltw_backb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_ltw_backb as text
%        str2double(get(hObject,'String')) returns contents of edit_ltw_backb as a double


% --- Executes during object creation, after setting all properties.
function edit_ltw_backb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ltw_backb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function shapeselect_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_ltw_backb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
