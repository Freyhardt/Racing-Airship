function trop = control_pos(axis, part)
global ls;
switch axis(1)
    case 1
        edit_name = 'edit_control_posx';
        slider_name = 'slider_control_posx';
        field = 'pos_x';
        min = -0.2;
        max = 1.2;
    case 2
        edit_name = 'edit_control_posy';
        slider_name = 'slider_control_posy';
        field = 'pos_y';
        min = -2;
        max = 2;
    case 3
        edit_name = 'edit_control_posz';
        slider_name = 'slider_control_posz';
        field = 'pos_z';
        min = -2;
        max = 2;
end
if part > 3
    eng = ['control' num2str(axis(1))];
else
    eng = ['control' num2str(ls.mass.control)];
end
switch part
    case 1
        edit = str2double(get(ls.handles.start.ha.(edit_name),'String'));
        set(ls.handles.start.ha.(slider_name),'Value',edit);
        ls.mass.(eng).(field) = edit;
        control_pos([ls.mass.control ls.mass.(eng).pos_x],8);
        name = ['edit_control' num2str(ls.mass.control) '_relpos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).pos_x);
    case 2
        slider = get(ls.handles.start.ha.(slider_name),'Value');
        set(ls.handles.start.ha.(edit_name),'String',num2str(slider));
        ls.mass.(eng).(field) = slider;
        name = ['edit_control' num2str(ls.mass.control) '_relpos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).pos_x);
        control_pos([ls.mass.control ls.mass.(eng).pos_x],8);
    case 3
        set(ls.handles.start.ha.edit_control_posx,'String',num2str(ls.mass.(eng).pos_x));
        set(ls.handles.start.ha.edit_control_posy,'String',num2str(ls.mass.(eng).pos_y));
        set(ls.handles.start.ha.edit_control_posz,'String',num2str(ls.mass.(eng).pos_z));
        set(ls.handles.start.ha.slider_control_posx,'Value',ls.mass.(eng).pos_x);
        set(ls.handles.start.ha.slider_control_posy,'Value',ls.mass.(eng).pos_y);
        set(ls.handles.start.ha.slider_control_posz,'Value',ls.mass.(eng).pos_z);
    case 4
        ls.mass.(eng).mass = axis(2);
        totalmass(1);
    case 5
        ls.mass.(eng).minprop = axis(1);
        if ls.mass.(eng).dynprop == 1
            ls.perf.prop_min = ls.mass.(eng).minprop;
            propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
            ls.mass.(eng).prop = ls.perf.prop_opt;
            name = ['edit_eng' num2str(ls.mass.eng) '_prop'];
            set(ls.handles.start.ha.(name),'String',ls.mass.(eng).prop);
        end
    case 6
        ls.mass.(eng).maxprop = axis(1);
        if ls.mass.(eng).dynprop == 1
            ls.perf.prop_max = ls.mass.(eng).maxprop;
            propeller(ls.mass.(eng).power * ls.mass.(eng).eff);
            ls.mass.(eng).prop = ls.perf.prop_opt;
            name = ['edit_eng' num2str(ls.mass.eng) '_prop'];
            set(ls.handles.start.ha.(name),'String',ls.mass.(eng).prop);
        end
    case 7
        ls.mass.(eng).pos_x = axis(2)/ls.geometry.length;
        name = ['edit_eng' num2str(axis(1)) '_relpos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).pos_x);
        control_pos(1,3);
    case 8
        ls.mass.(eng).abspos = axis(2)*ls.geometry.length;
        name = ['edit_control' num2str(axis(1)) '_abspos'];
        set(ls.handles.start.ha.(name),'String',ls.mass.(eng).abspos);
        ls.mass.(eng).pos_x = axis(2);
        control_pos(1,3);
    case 9
        ls.mass.(eng).power = axis(2);
    case 10
        ls.mass.(eng).prop = axis(2);
    case 11
        ls.mass.(eng).mass = axis(2);
        totalmass
    case 12
        ls.mass.(eng).eff = axis(2);
end
if ls.settings.iter == 0
    trim;
end