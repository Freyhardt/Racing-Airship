function drawing()
global ls;
if ls.settings.iter == 0
    axes(ls.handles.start.ha.display);
    cla;
    hold on;
    axis auto;
    %axis standard;
    axis equal;
    dim_3d = ls.settings.dim; % 0 = 2D 1 = 3D
    txt_x = -ls.geometry.length * 0.01;
    txt_y = -ls.geometry.length *0.011;
    txt_y2 = ls.geometry.length *0.012;
    ltw_start = ls.ltw.start_point * ls.geometry.length;
    ltw_part = 5; % 5 = ohne Projection 8 = mit
    points_x = ls.ltw.points_x(1:ltw_part);
    points_y = ls.ltw.points_y(1:ltw_part);
    points_z = ls.ltw.points_y(1:ltw_part).*ls.ltw.ratio_hltw;
    points_xz = ls.ltw.ratio_hltw * points_x;
    shape = ls.geometry.shape;
    z_1 = 0 * ones(length(points_x),1);
    % plot3(ltw_start+points_x,z_1, points_y);
    % plot3(ltw_start + points_x,z_1, -points_y);
    % plot3(ltw_start+points_xz, points_z, z_1);
    % plot3(ltw_start + points_xz, -points_z,z_1);
    %z_1 = 0 * ones(length(points_x),length(points_x));
    %[x_1, y_1] = meshgrid(ltw_start + points_x, points_y);
    if dim_3d == 1
        [z, y, x] = cylinder(shape(:,2));
        surf(ls.geometry.length*x, z, y);
        %surface(x_1, y_1, z_1);
        colormap bone;
        plot3(ltw_start+points_x,z_1, points_y);
        plot3(ltw_start + points_x,z_1, -points_y);
        plot3(ltw_start+points_xz, points_z, z_1);
        plot3(ltw_start + points_xz, -points_z,z_1);
        
        %view(10, 80);
    else
        if ls.settings.cuts_view == 1
            cut_x = ls.geometry.cut_x;
            cut_y = ls.geometry.cut_y;
            plot(cut_x,cut_y,'r',cut_x,-cut_y,'r');
        end
        plot(shape(:,1),shape(:,2),'k',shape(:,1),-shape(:,2),'k','LineWidth', 1);
        plot3(ltw_start+points_xz,z_1, points_z);
        plot3(ltw_start + points_xz,z_1, -points_z);
        plot3(ltw_start+points_x, points_y, z_1);
        plot3(ltw_start + points_x, -points_y,z_1);
        view(0,90);
    end
    plot(ls.geometry.vsp * ls.geometry.length, 0, 'O');
    text(ls.geometry.vsp * ls.geometry.length + txt_x, txt_y,'VSP'); %,'fontsize',8);
    plot((ls.ltw.sp+ls.geometry.vsp) * ls.geometry.length, 0, 'O');
    text((ls.ltw.sp+ls.geometry.vsp) * ls.geometry.length + txt_x, txt_y-0.003,'LTW_S_P'); %,'fontsize',8);
    plot((ls.ltw.np+ls.geometry.vsp) * ls.geometry.length, 0, 'O');
    text((ls.ltw.np+ls.geometry.vsp) * ls.geometry.length + txt_x, txt_y2,'NP'); %,'fontsize',8);
    for i = 1:5
        name = payload_mass(i, 4);
        if ls.mass.(name).mass ~= 0
            plot(ls.mass.(name).pos_x * ls.geometry.length, -hullpos(ls.mass.(name).pos_x * ls.geometry.length), 'O');
            text(ls.mass.(name).pos_x * ls.geometry.length + txt_x, -hullpos(ls.mass.(name).pos_x * ls.geometry.length) + txt_y,name);
        end
    end
    for i = 1:4
        name = ['eng' num2str(i)];
        if ls.mass.(name).mass ~= 0 && ls.mass.engon(i) == 1
            plot(ls.mass.(name).pos_x * ls.geometry.length, -hullpos(ls.mass.(name).pos_x * ls.geometry.length), 'O');
            text(ls.mass.(name).pos_x * ls.geometry.length + txt_x, -hullpos(ls.mass.(name).pos_x * ls.geometry.length) + txt_y,name);
        end
        name = ['control' num2str(i)];
        if ls.mass.(name).mass ~= 0 && ls.mass.controlon(i) == 1
            plot(ls.mass.(name).pos_x * ls.geometry.length, -hullpos(ls.mass.(name).pos_x * ls.geometry.length), 'O');
            text(ls.mass.(name).pos_x * ls.geometry.length + txt_x, -hullpos(ls.mass.(name).pos_x * ls.geometry.length) + txt_y2,name);
        end
    end
    hold off;
    axis equal;
end