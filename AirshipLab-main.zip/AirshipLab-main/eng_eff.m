function eff = eng_eff(power, n)
power = power/1000;
n_mot1 = 0.5275 + 0.3224 * log10(power) - 0.0625*(log10(power))^2;
eff = n_mot1 + (1-n_mot1)/3 * log10(n/750);