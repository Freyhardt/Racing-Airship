function ghl = mass_eng(eng, pos)
global ls;
mass_name = ['edit_eng' num2str(eng) ''];
relpos_name = ['edit_eng' num2str(eng) '_relpos'];
abspos_name = ['edit_eng' num2str(eng) '_abspos'];
power_name = ['edit_eng' num2str(eng) '_power'];
eff_name = ['edit_eng' num2str(eng) '_eff'];
prop_name = ['edit_eng' num2str(eng) '_prop'];
if pos == 1
    name = ['check_engi' num2str(eng)];
    on = get(ls.handles.start.ha.(name),'Value');
    ls.mass.engon(eng) = on;
    if on == 1 
        set(ls.handles.start.ha.(mass_name),'Enable','on');
        set(ls.handles.start.ha.(relpos_name),'Enable','on');
        set(ls.handles.start.ha.(abspos_name),'Enable','on');
        set(ls.handles.start.ha.(power_name),'Enable','on');
        set(ls.handles.start.ha.(eff_name),'Enable','on');
        set(ls.handles.start.ha.(prop_name),'Enable','on');
    else
        set(ls.handles.start.ha.(mass_name),'Enable','off');
        set(ls.handles.start.ha.(relpos_name),'Enable','off');
        set(ls.handles.start.ha.(abspos_name),'Enable','off');
        set(ls.handles.start.ha.(power_name),'Enable','off');
        set(ls.handles.start.ha.(eff_name),'Enable','off');
        set(ls.handles.start.ha.(prop_name),'Enable','off');
        
    end
end
if ls.settings.iter == 0
ls.mass.eng = eng;
name = ['eng' num2str(eng)];
ls.perf.min_prop = ls.mass.(name).prop;
ls.perf.max_prop = ls.mass.(name).prop;
%propeller(ls.mass.(name).power * ls.mass.(name).eff); 
multi_prop(400);
set(ls.handles.start.ha.menu_eng,'Value',eng);

totalmass(1);
trim;
end;