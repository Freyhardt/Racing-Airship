function neu = volumen()%handles,eventdata,hObject)
global ls;
switch ls.geometry.set
    case 1
        shape = gertler(ls.gertler.r0,ls.gertler.r1,ls.gertler.cp,ls.gertler.m,...
        ls.geometry.l2d,ls.geometry.dots);
        shape(2,ls.geometry.dots) = 0;
    case 2
        shape = ls.geometry.shape';
end
werte = length(shape);
scale = ls.geometry.volume/ls.geometry.volume2;
ls.geometry.length = ls.geometry.length*(scale^(1/3));
ls.geometry.thick = ls.geometry.thick*(scale^(1/3));
%laenge_test2 = ls.geometry.length;
%dicke_test2 = ls.geometry.thick;
set(ls.handles.start.ha.edit_length,'String',num2str(ls.geometry.length));
set(ls.handles.start.ha.edit_thickness,'String',num2str(ls.geometry.thick));
shape = shape';
volumen = 0;
sur_face = 0;
shape(:,1) = shape(:,1)*ls.geometry.length;
shape(:,2) = shape(:,2)*ls.geometry.thick*ls.geometry.l2d;
for i=1:werte-1
    volume(i) = ((shape(i,2) + shape(i+1,2)) / 2)^2 * pi *...
        (shape(i+1,1)-shape(i,1));
    volumen = volumen + volume(i);
    sur_face(i) = (shape(i,2) + shape(i+1,2)) * pi * (shape(i+1,1)-shape(i,1));
    sur_face = sur_face(i) + sur_face;
end
ls.geometry.surface = sur_face(1);
ls.geometry.volume = volumen;
x = shape(:,1);
y = shape(:,2);
x_sp = 0;
zusammen = 0;
for i=1:werte-2
    dx = (x(i+1)-x(i));
    if y(i)<max(y)
        d1 = (dx.^2*y(i)+2/3*dx*(y(i+1)-y(i))*dx);
        d(i) = (2*(dx)*y(i+1));
        %x_sp(i) = (dx.^2*y(i)+2/3*dx*(y(i+1)-y(i))*dx)/(2*(dx)*y(i+1));
        x_sp(i) = x(i) + d1/d(i);
    else
        d1 = (dx.^2*y(i)+1/3*dx*(y(i)-y(i+1))*dx);
        d(i) = (2*(dx)*y(i));
        x_sp(i) = x(i) + d1/d(i);
    end
end

%(shape(i,2)+shape(i+1,2))/2*(shape(i+1,2)-shape(i,2))*shape(
ls.geometry.vsp = round(sum(x_sp.*d)/sum(d)*1000/ls.geometry.length)/1000;

%axes(ls.handles.start.ha.display);
%[z y x] = cylinder(shape(:,2));
%surf(ls.geometry.length*x,y, z);


%plot(shape(:,1),shape(:,2),shape(:,1),-shape(:,2));
%shape = shape';
%plot(shape(1,:),shape(2,:),shape(1,:),-shape(2,:));
ls.geometry.shape = shape;

%axis([0 1 -0.2 0.2])
%[z y x] = cylinder(shape(:,2));
%surf(ls.geometry.length*x,y, z);
%view(0, 0);
%view(90,0);
%ylim([-0.3 0.3]);
%xlim([0 ls.geometry.length]);
ls.geometry.volume2 = ls.geometry.volume;
ls.mass.hull = ls.geometry.surface * ls.mass.hull_per_m + max(ls.geometry.cut_x)...
    * ls.geometry.cuts * 2 * ls.geometry.hull_overlay/1000 * ls.mass.hull_per_m;
ls.hull.k = k_factor(1/ls.geometry.l2d);
ls.hull.moment = ls.aerodyn.rho / 2 * ls.hull.k * sind(2 * ls.hull.alpha)* ...
    ls.geometry.volume;

if ls.settings.iter == 0
set(ls.handles.start.ha.edit_vsp,'String',num2str(ls.geometry.vsp));
set(ls.handles.start.ha.edit_volume,'String',num2str(ls.geometry.volume));
set(ls.handles.start.ha.edit_surface2,'String',num2str(ls.geometry.surface));
set(ls.handles.start.ha.edit_l2d,'String',num2str(ls.geometry.l2d));
aerostats();
sternplain();
drawing();
end
spec_vol = ls.geometry.volume/ls.geometry.length^3;%/ls.geometry.thick^2;
f = (pi/spec_vol/3)^(1/2);