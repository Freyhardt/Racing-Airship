function sternplain_material(setting)
global ls;
switch setting
    case 1
        ls.ltw.a_weight = 120;
        set(ls.handles.start.ha.edit_ltw_m_per_m2,'Enable','off');
        set(ls.handles.start.ha.edit_ltw_m_per_m2,'String',num2str(ls.ltw.a_weight));
    case 2
        ls.ltw.a_weight = 200;
        set(ls.handles.start.ha.edit_ltw_m_per_m2,'Enable','off');
        set(ls.handles.start.ha.edit_ltw_m_per_m2,'String',num2str(ls.ltw.a_weight));
    case 3
        set(ls.handles.start.ha.edit_ltw_m_per_m2,'Enable','on');
    case 4
        ls.ltw.a_weight = str2double(get(ls.handles.start.ha.edit_ltw_m_per_m2,'String'));
    case 5
        ls.ltw.mass = str2double(get(ls.handles.start.ha.edit_ltw_mass,'String'));
end
totalmass(1);
sternplain();