function iteration()
global ls;
ls.settings.iter = 1;
difference = 1;
ls.mass.multi_prop = 0;
ls.perf.itersteps = 100;
v_select = 15;
t = 0;
% for l2d = 2:1:6
%     step = l2d-1
%     difference = 1;
%     ls.geometry.l2d = l2d;
%     ls.geometry.thick = ls.geometry.length/ls.geometry.l2d;
%     ls.perf.power = 0.1;
%     propeller(ls.perf.power);
%     while v_select > ls.perf.v_max
%         propeller(ls.perf.power)
%         ls.mass.eng1.mass = eng_mass(ls.perf.power);
%         ls.perf.power = ls.perf.power + 0.2;
%         

        while difference > 0.001 && t < 100
            ls.geometry.volume = (ls.mass.totalmass/1000 / ls.aerostat.lift_spec);
            volumen();
            sternplain();
            trim();
            totalmass(1);
            difference = abs(1 - ls.geometry.volume/(ls.mass.totalmass/1000 / ls.aerostat.lift_spec));
            t = t+1;
    
        end
%     end
%     ls.settings.iter = 0;
%     volumen();
%     ltw_set(4);
%     sternplain();
%     trim();
%     totalmass(1);
%     %lzud = ls.geometry.l2d
%     laenge = ls.geometry.length;
%     volum = ls.geometry.volume;
%     power(l2d-1) = ls.perf.power;
%     motor_masse(l2d-1) = ls.mass.eng1.mass;
%     vol(l2d-1) = ls.geometry.volume;
%     step = l2d-1
%  %  pause;
% end
%t = t;
%test = ls.settings.iter
ls.settings.iter = 0;
volumen();
ltw_set(4);
sternplain();
trim();
totalmass(1);