function ca_max1 = ca_max(REY)
ca_max1 = 0.1449*log(REY) - 0.9054;
