function result = payload_mass(namen, sets)
global ls;
switch namen
    case 1
        name = 'payload1';
    case 2
        name = 'payload2';
    case 3
        name = 'accu';
    case 5
        name = 'trim';
    case 4
        name = 'receiver';
end
switch sets
    case 1
        field = ['edit_' name '_mass'];
        mass = str2double(get(ls.handles.start.ha.(field),'String'));
        ls.mass.(name).mass = mass;
        totalmass(1);
        trim;
    case 2
        field = ['edit_' name '_relpos'];
        pos_x = str2double(get(ls.handles.start.ha.(field),'String'));
        ls.mass.(name).pos_x = pos_x;
        field = ['edit_' name '_abspos'];
        set(ls.handles.start.ha.(field),'String',num2str(pos_x * ls.geometry.length));
        %if ls.mass.accu_trim == 0 && namen ~= 5
        if namen ~= 3 && namen ~= 5
            trim();
        end
        if namen == 3 && ls.mass.accu_trim == 0
            trim();
        end
    case 3
        field = ['edit_' name '_abspos'];
        pos_x = str2double(get(ls.handles.start.ha.(field),'String'));
        ls.mass.(name).pos_x = pos_x / ls.geometry.length;
        field = ['edit_' name '_relpos'];
        set(ls.handles.start.ha.(field),'String',num2str(ls.mass.(name).pos_x));
        trim;
    case 4
        result = name;
    case 5
        ls.mass.methode = 0;
        ls.mass.reserve = str2double(get(ls.handles.start.ha.edit_mass_reserve,'String')) / 100;
        trim;
    case 6
        ls.mass.accu_trim = namen;
        trim;
        if namen == 1
            set(ls.handles.start.ha.edit_mass_varibat_from,'Enable','on');
            set(ls.handles.start.ha.edit_mass_varibat_to,'Enable','on');
            set(ls.handles.start.ha.edit_accu_relpos,'Enable','off');
            set(ls.handles.start.ha.edit_accu_abspos,'Enable','off');
        else
            set(ls.handles.start.ha.edit_mass_varibat_from,'Enable','off');
            set(ls.handles.start.ha.edit_mass_varibat_to,'Enable','off');
            set(ls.handles.start.ha.edit_accu_relpos,'Enable','on');
            set(ls.handles.start.ha.edit_accu_abspos,'Enable','on');
        end
    case 7
        ls.mass.accu.min_pos = str2double(get(ls.handles.start.ha.edit_mass_varibat_from,'String'));
        trim;
    case 8
        ls.mass.accu.max_pos = str2double(get(ls.handles.start.ha.edit_mass_varibat_to,'String'));
        trim;
    case 9
        ls.mass.methode = 1;
        totalmass(1);
        trim();
end
