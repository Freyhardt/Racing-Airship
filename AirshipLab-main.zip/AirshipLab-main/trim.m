function cool = trim()
global ls;
moment = 0;
sum_pos_x = 0;
trim_tolerance = 0.001;
trim_from = 0;
trim_to = 1;
for i = 1:4
    if ls.mass.engon(i) == 1
        eng = ['eng' num2str(i)];
        mass = ls.mass.(eng).mass;
        rel_pos_x = ls.mass.(eng).pos_x - ls.geometry.vsp;
        moment = moment + mass * rel_pos_x;
    end
    if ls.mass.controlon(i) == 1
        control = ['control' num2str(i)];
        mass = ls.mass.(control).mass;
        rel_pos_x = ls.mass.(control).pos_x - ls.geometry.vsp;
        moment = moment + mass * rel_pos_x;
    end
end
for i = 1:length(ls.mass.servos)
    if ls.mass.servos(i) == 1
        name = ['servo0' num2str(i)];
        mass = ls.mass.(name).mass;
        rel_pos_x = ls.mass.(name).pos_x - ls.geometry.vsp;
        moment = moment + mass * rel_pos_x;
    end
end
for i = 1:4
    if i == 3 %&& ls.mass.accu_trim == 1
        check = 1;
    else
        mass = ls.mass.(payload_mass(i,4)).mass;
        rel_pos_x = ls.mass.(payload_mass(i,4)).pos_x - ls.geometry.vsp;
            moment = moment + mass * rel_pos_x;
    end
end
ls.mass.accu_limit = 0;
moment = moment + ls.ltw.mass * (ls.ltw.sp) + ls.mass.eng_cable * ...
    ls.mass.eng_cable_sp + ls.mass.servo_cable * ls.mass.servo_cable_sp;
if ls.mass.accu_trim == 1 && ls.mass.accu.mass > 0
    x_sp_akku = -moment/ls.mass.accu.mass + ls.geometry.vsp;
    if x_sp_akku < ls.mass.accu.min_pos
        x_sp_akku = ls.mass.accu.min_pos;
        ls.mass.accu_limit = 1;
    end
    if x_sp_akku > ls.mass.accu.max_pos
        x_sp_akku = ls.mass.accu.max_pos;
        ls.mass.accu_limit = -1;
    end
    ls.mass.accu.pos_x = x_sp_akku;
    %set(ls.handles.start.ha.edit_accu_relpos,'String',num2str(x_sp_akku));
    
    x_sp_akku = x_sp_akku;
else
    ls.mass.accu_limit = moment/ls.mass.totalmass;
    x_sp_akku = ls.mass.accu.pos_x;
end
moment = moment + ls.mass.accu.mass * (x_sp_akku - ls.geometry.vsp);
ls.mass.accu_limit = moment/ls.mass.totalmass;
masse_trim = 0;
trim_pos = ls.mass.trim.pos_x;
if ls.mass.accu_limit > 0 + trim_tolerance*ls.geometry.length
    trim_pos = -ls.geometry.vsp - trim_from;
    masse_trim = -moment/trim_pos;
    trim_pos = trim_pos + ls.geometry.vsp;
end
if ls.mass.accu_limit < 0 - trim_tolerance*ls.geometry.length
    trim_pos = trim_to - ls.geometry.vsp;
    masse_trim = -moment/trim_pos;
    trim_pos = trim_pos + ls.geometry.vsp;
end
ls.mass.trim.pos_x = trim_pos;
ls.mass.trim.mass = masse_trim;
if ls.settings.iter == 0
ls.settings.trimon = 1;
set(ls.handles.start.ha.edit_trim_mass,'String',num2str(masse_trim));
set(ls.handles.start.ha.edit_trim_relpos,'String',num2str(trim_pos));
set(ls.handles.start.ha.edit_accu_relpos,'String',num2str(x_sp_akku));
if ls.mass.accu_trim == 1
    payload_mass(3,2);
end
payload_mass(5,2);
servo_mass(1 ,1);
totalmass(1);
drawing();
ls.settings.trimon = 0;
end