function nope = sheetset(sheet_selected)
global ls;
switch ls.settings.sheet
    case 1
        set(ls.handles.start.ha.panel_overview,'visible','off');
    case 2
        set(ls.handles.start.ha.panel_shape,'visible','off');
    case 3
        set(ls.handles.start.ha.panel_performance,'visible','off');
    case 4
        set(ls.handles.start.ha.panel_masses,'visible','off');
    case 5
        set(ls.handles.start.ha.panel_sternplain,'visible','off');
end
switch sheet_selected
    case 1
        set(ls.handles.start.ha.panel_overview,'visible','on'); 
    case 2
        set(ls.handles.start.ha.panel_shape,'visible','on');
    case 3
        set(ls.handles.start.ha.panel_performance,'visible','on');
    case 4
        set(ls.handles.start.ha.panel_masses,'visible','on');
    case 5
        set(ls.handles.start.ha.panel_sternplain,'visible','on');
end
ls.settings.sheet = sheet_selected;