function outputer = gasselect(t)
global ls;
switch t
    case 1
        ls.aerostat.r_he = 2077;
        ls.aerostat.t_delta = 0;
        set(ls.handles.start.ha.edit_k_air,'enable','off');
        set(ls.handles.start.ha.edit_k_he,'enable','off');
        set(ls.handles.start.ha.edit_k_he,'String', '2077');
        set(ls.handles.start.ha.edit_t_delta,'String', '0');
    case 2
        ls.aerostat.r_he = 4124;
        ls.aerostat.t_delta = 0;
        set(ls.handles.start.ha.edit_k_air,'enable','off');
        set(ls.handles.start.ha.edit_k_he,'enable','off');
        set(ls.handles.start.ha.edit_k_he,'String', '4124');
        set(ls.handles.start.ha.edit_t_delta,'String', '0');
    case 3
        ls.aerostat.r_he = 287;
        ls.aerostat.t_delta = 70;
        set(ls.handles.start.ha.edit_k_air,'enable','off');
        set(ls.handles.start.ha.edit_k_he,'enable','off');
        set(ls.handles.start.ha.edit_k_he,'String', '287');
        set(ls.handles.start.ha.edit_t_delta,'String', '70');
    case 4
        set(ls.handles.start.ha.edit_k_air,'enable','on');
        set(ls.handles.start.ha.edit_k_he,'enable','on');
end
tempinput(3);
aerostats();