function masse = totalmass(reserve_switch) %reserveswitch 0 = Gesamtmasse ausgeben und Reserve berechnen 1 = Reserve mit einbeziehen
global ls;
mass = 0;
cable_mass = 0;
x_sp = 0;
t = 2;
for i = 1:4
    if ls.mass.engon(i) == 1
        eng = ['eng' num2str(i)];
        mass = mass + ls.mass.(eng).mass;
    end
    if ls.mass.controlon(i) == 1
        control = ['control' num2str(i)];
        mass = mass + ls.mass.(control).mass;
    end
    if ls.mass.controlon(i) == 1 && ls.mass.engon(i) == 1 && ls.mass.(control).pos_x ~= ls.mass.(eng).pos_x
        eng_cable = abs(ls.mass.(eng).pos_x - ls.mass.(control).pos_x) * 1.1;
        cable_mass(t) = eng_cable * ls.mass.eng_cable_per_m;
        if ls.mass.(eng).pos_x <= ls.mass.(control).pos_x
            x_sp(t) = ls.mass.(eng).pos_x + eng_cable/2;
        else
            x_sp(t) = ls.mass.(control).pos_x + eng_cable/2;
        end
        x_sp(1) = (x_sp(t) * cable_mass(1) + x_sp(t) * cable_mass(t)) / (cable_mass(1) + cable_mass(t));
        cable_mass(1) = cable_mass(1) + cable_mass(t);
        t = t + 1;
    end
    if ls.mass.accu.mass > 0 && ls.mass.controlon(i) == 1 && ls.mass.(control).pos_x ~= ls.mass.accu.pos_x
        eng_cable = abs(ls.mass.accu.pos_x - ls.mass.(control).pos_x) * 1.1;
        cable_mass(t) = eng_cable * ls.mass.eng_cable_per_m;
        if ls.mass.accu.pos_x <= ls.mass.(control).pos_x
            x_sp(t) = ls.mass.accu.pos_x + eng_cable/2;
        else
            x_sp(t) = ls.mass.(control).pos_x + eng_cable/2;
        end
        x_sp(1) = (x_sp(t) * cable_mass(1) + x_sp(t) * cable_mass(t)) / (cable_mass(1) + cable_mass(t));
        cable_mass(1) = cable_mass(1) + cable_mass(t);
        t = t + 1;
    end
end
mass = mass + cable_mass(1);
ls.mass.eng_cable = cable_mass(1);
ls.mass.eng_cable_sp = x_sp(1);
cable_mass = 0;
x_sp = 0;
t = 2;
for i = 1:length(ls.mass.servos)
    if ls.mass.servos(i) == 1
        if i <= 9
            name = ['servo0' num2str(i)];
        else
            name = ['servo' num2str(i)];
        end
        mass = mass + ls.mass.(name).mass;
        if ls.mass.(name).mass ~= 0 && ls.mass.receiver.mass ~= 0 && ls.mass.(name).pos_x ~= ls.mass.receiver.pos_x
            servo_cable = abs(ls.mass.(name).pos_x - ls.mass.receiver.pos_x) * 1.1;
            cable_mass(t) = servo_cable * ls.mass.servo_cable_per_m;
            if ls.mass.(name).pos_x <= ls.mass.receiver.pos_x
                x_sp(t) = ls.mass.(name).pos_x + servo_cable/2;
            else
                x_sp(t) = ls.mass.receiver.pos_x + servo_cable/2;
            end
            x_sp(1) = (x_sp(t) * cable_mass(1) + x_sp(t) * cable_mass(t)) / (cable_mass(1) + cable_mass(t));
            cable_mass(1) = cable_mass(1) + cable_mass(t);
            servo_cable = abs(ls.mass.(name).pos_z - hullpos(ls.mass.receiver.pos_x))*1.4;
            cable_mass(t) = servo_cable * ls.mass.servo_cable_per_m;
            x_sp(t) = ls.mass.(name).pos_x;
            x_sp(1) = (x_sp(t) * cable_mass(1) + x_sp(t) * cable_mass(t)) / (cable_mass(1) + cable_mass(t));
            cable_mass(1) = cable_mass(1) + cable_mass(t);
            t = t + 1;
        end
    end
end
mass = mass + cable_mass(1);
ls.mass.servo_cable = cable_mass(1);
ls.mass.servo_cable_sp = x_sp(1);
for i = 1:5
    mass = mass + ls.mass.(payload_mass(i,4)).mass;
end
mass = mass + ls.mass.servo_cable + ls.mass.eng_cable + ls.ltw.mass + ls.mass.hull;
if ls.settings.iter == 0
    if ls.mass.methode == 0
        mass = mass * (ls.mass.reserve + 1);
        set(ls.handles.start.ha.edit_mass,'String',mass);
    else
        ls.mass.reserve = -(1 - (ls.aerostat.lift_kg*1000/ mass));
        set(ls.handles.start.ha.edit_mass_reserve,'String',ls.mass.reserve*100);
        set(ls.handles.start.ha.edit_mass,'String',mass);
    end
    set(ls.handles.start.ha.edit_hull_mass,'String',num2str(ls.mass.hull));
    set(ls.handles.start.ha.edit_eng_cable_mass,'String',num2str(ls.mass.eng_cable));
    set(ls.handles.start.ha.edit_servo_cable_mass,'String',num2str(ls.mass.servo_cable));
end
ls.mass.totalmass = mass;