function cable_set
global ls;
ls.mass.eng_cable_per_m = str2double(get(ls.handles.start.ha.edit_eng_cable_rel_mass,'String'));
ls.mass.servo_cable_per_m = str2double(get(ls.handles.start.ha.edit_servo_cable_rel_mass,'String'));
totalmass(1);
trim();