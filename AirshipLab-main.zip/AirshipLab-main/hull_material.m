function hull_material(way)
global ls;
switch way
    case 1
        ls.geometry.cuts = str2double(get(ls.handles.start.ha.edit_hull_cuts,'String'));
        schablone();
    case 2
        ls.geometry.hull_overlay = str2double(get(ls.handles.start.ha.edit_cuts_overlay,'String'));
    case 3
        schablone();
        [file,path] = uiputfile('.sldcrv','Shape exportieren...');
        exportfile = [ls.geometry.cut_x.*1000 ls.geometry.cut_y.*1000];
        %xlswrite([path file], exportfile);
        l = length(exportfile);
        z(1:l) = 0;
        ziel = [exportfile z'];
        for x = 1:l
            genau{x,1} = [num2str(ziel(x,1)) 'mm'];
            genau{x,2} = [num2str(ziel(x,2)) 'mm'];
            genau{x,3} = [num2str(ziel(x,3)) 'mm'];
        end
        fid = fopen([path file],'w');
        for k = 1:l
            fprintf(fid,'%s',genau{k,1});
            fprintf(fid, '%s', ' ');
            fprintf(fid,'%s',genau{k,2});
            fprintf(fid, '%s', ' ');
            fprintf(fid,'%s\n',genau{k,3});
        end
        fclose(fid);
    case 4
        ls.mass.hull_per_m = str2double(get(ls.handles.start.ha.edit_mass_per_m2,'String'));
    case 5
        seti = get(ls.handles.start.ha.menu_hull_material,'Value');
        switch seti
            case 1
                ls.mass.hull_per_m = 26;
                set(ls.handles.start.ha.edit_mass_per_m2,'String',num2str( ls.mass.hull_per_m));
                set(ls.handles.start.ha.edit_mass_per_m2,'Enable','off');
            case 2
                ls.mass.hull_per_m = 16;
                set(ls.handles.start.ha.edit_mass_per_m2,'String',num2str( ls.mass.hull_per_m));
                set(ls.handles.start.ha.edit_mass_per_m2,'Enable','off');
            case 3
                set(ls.handles.start.ha.edit_mass_per_m2,'Enable','on');
        end
    case 6
        ls.settings.cuts_view = get(ls.handles.start.ha.check_cuts_view,'Value');
        schablone();
end
volumen();