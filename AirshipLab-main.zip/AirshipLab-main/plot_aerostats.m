function plot_aerostats()
global ls;
cla;
hold on;
for t = 1:3
    switch t
        case 1
            ls.aerostat.p_air = 101300;
            symb = [0 0 1];
        case 2
            ls.aerostat.p_air = 104110;
            symb = [1 0 0];
        case 3
            ls.aerostat.p_air = 97330;
            symb = [0.466666668653488 0.674509823322296 0.18823529779911];
    end
    ls.aerostat.p_he = ls.aerostat.p_air;
    for i = 0:45
        ls.aerostat.t_air = 273.15 + i-10;
        ls.aerostat.t_he = ls.aerostat.t_air;
        aerostats();
        lift(i+1) = ls.aerostat.lift_spec;
    end
    x = -10:i-10;
    plot(x,lift, 'LineWidth',2,'Color',symb );
end


xlabel('Temperatur [�C]','FontSize',11,'FontName','Cambria');
ylabel('spez. Auftrieb[kg/m�]','FontSize',11,'FontName','Cambria');