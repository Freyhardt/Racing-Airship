function endwert = tempunit(select)
global ls;
switch select
    case 1
        set(ls.handles.start.ha.text38,'String','�C');
        set(ls.handles.start.ha.text39,'String','�C');
        set(ls.handles.start.ha.text40,'String','�C');
        set(ls.handles.start.ha.edit_t_air,'String',num2str(ls.aerostat.t_air-ls.aerostat.kelvin));
        set(ls.handles.start.ha.edit_t_he,'String',num2str(ls.aerostat.t_he-ls.aerostat.kelvin));
        set(ls.handles.start.ha.edit_t_delta,'String',num2str(ls.aerostat.t_delta));
        ls.settings.tempunit = 1;
    case 2
        set(ls.handles.start.ha.text38,'String','�F');
        set(ls.handles.start.ha.text39,'String','�F');
        set(ls.handles.start.ha.text40,'String','�F');
        set(ls.handles.start.ha.edit_t_air,'String',num2str(ls.aerostat.t_air*1.8-459.67));
        set(ls.handles.start.ha.edit_t_he,'String',num2str(ls.aerostat.t_he*1.8-459.67));
        set(ls.handles.start.ha.edit_t_delta,'String',num2str(ls.aerostat.t_delta*1.8));
        ls.settings.tempunit = 2;
    case 3
        set(ls.handles.start.ha.text38,'String','�K');
        set(ls.handles.start.ha.text39,'String','�K');
        set(ls.handles.start.ha.text40,'String','�K');
        set(ls.handles.start.ha.edit_t_air,'String',num2str(ls.aerostat.t_air));
        set(ls.handles.start.ha.edit_t_he,'String',num2str(ls.aerostat.t_he));
        set(ls.handles.start.ha.edit_t_delta,'String',num2str(ls.aerostat.t_delta));
        ls.settings.tempunit = 3;
end
