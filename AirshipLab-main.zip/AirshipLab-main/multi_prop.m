function anything = multi_prop(steps)
global ls;
% v2 = 0;
% for i = 1:4
%     if ls.mass.engon(i) == 1
%         name(i,:) = ['eng' num2str(i)];
%         if v2 < ls.perf.(name(i,:)).v2
%             v2 = ls.perf.(name(i,:)).v2;
%         end
%     end
% end
% drag = -1;
% thrust = 0;
% v1 = 0;
% while drag <= thrust && v1 < v2
%     thrust = 0;
%     for i = 1:4
%         if ls.mass.engon(i) == 1
%             thrust = ls.aerodyn.rho / 2 * (ls.mass.(name(i,:)).prop / 2)^2 * pi() * ...
%                 (ls.perf.(name(i,:)).v2^2 - v1^2) + thrust;
%         end
%     end
%     if v1 == 0
%             ls.perf.maxpower = thrust;
%     end
%     drag = aerodyn(v1, ls.settings.aerometh);
%     v1 = v1 + v2/(steps-1);
% end
% v_max = v1;
% drag = drag;
% thrust = thrust;
%     
        
        